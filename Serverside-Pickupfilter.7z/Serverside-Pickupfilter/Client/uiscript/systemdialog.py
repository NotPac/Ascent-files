## IMPORTANT: 
## Maybe your client is loading this script from locale. 
## If you get key-errors "pickup_filter_button" ->
## Check "locale/xx/ui/systemdialog.py" and add this change there too.

[...]
			{
				"name" : "board",
				"type" : "thinboard",

				"x" : 0,
				"y" : 0,

				"width" : 200,
				"height" : 368,

				"children" :
				(
					#Replace:
					# {
						# "name" : "help_button",
						# "type" : "button",

						# [...]
					# },
				
					{
						"name" : "pickup_filter_button",
						"type" : "button",

						"x" : 10,
						"y" : 17,

						"text" : uiScriptLocale.PICKUP_FILTER_TITLE,

						"default_image" : ROOT + "XLarge_Button_01.sub",
						"over_image" : ROOT + "XLarge_Button_02.sub",
						"down_image" : ROOT + "XLarge_Button_03.sub",
					},
[...]
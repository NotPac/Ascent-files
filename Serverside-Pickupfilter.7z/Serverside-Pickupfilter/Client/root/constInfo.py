
[...]
# Add somewhere on top, pay attention that "import app" is called before!

if app.ENABLE_PICKUP_FILTER:
	PICKUP_MODE = 0
	PICKUP_FLAG = 0
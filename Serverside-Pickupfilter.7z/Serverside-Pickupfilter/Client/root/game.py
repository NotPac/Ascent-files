[...]
			
		if app.ENABLE_PICKUP_FILTER:
			serverCommandList["setpickupmode"] = self.__SetPickupMode
			serverCommandList["setpickupblock"] = self.__SetPickupBlock
			
		self.serverCommander=stringCommander.Analyzer() #Search for this line
		
[...]

#Place at end of file:

	if app.ENABLE_PICKUP_FILTER:
		def __SetPickupMode(self, mode):
			constInfo.PICKUP_MODE = int(mode)
			
		def __SetPickupBlock(self, flag):
			constInfo.PICKUP_FLAG = int(flag)
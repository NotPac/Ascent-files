[...]

if app.ENABLE_PICKUP_FILTER:
	import uiPickupFilter
	
[...]

	def __Initialize(self):
		self.systemOptionDlg = None
		self.gameOptionDlg = None
		
		if app.ENABLE_PICKUP_FILTER:
			self.pickupFilterDialog = None
			
[...]

	def __LoadSystemMenu_Default(self):
		[...]
		
		#Replace:
		# self.GetChild("help_button").SAFE_SetEvent(self.__ClickHelpButton)
		
		if app.ENABLE_PICKUP_FILTER:
			self.GetChild("pickup_filter_button").SAFE_SetEvent(self.__ClickPickupFilterButton)
		else:
			self.GetChild("help_button").SAFE_SetEvent(self.__ClickHelpButton)
			
		[...]
		
	def Destroy(self):
		[...]

		if self.systemOptionDlg:
			self.systemOptionDlg.Destroy()
			
		if app.ENABLE_PICKUP_FILTER and self.pickupFilterDialog:
			self.pickupFilterDialog.Destroy()
			
		[...]
		
	def __ClickGameOptionButton(self):
		[...]
		
	if app.ENABLE_PICKUP_FILTER:
		def __ClickPickupFilterButton(self):
			self.Close()

			if not self.pickupFilterDialog:
				self.pickupFilterDialog = uiPickupFilter.OptionDialog()

			self.pickupFilterDialog.Show()
[...]

ACMD(do_setblockmode)
{
	[...]
}

#ifdef ENABLE_PICKUP_FILTER
ACMD(do_setpickupmode)
{
	char arg1[256];
	char arg2[256];

	two_arguments(argument, arg1, sizeof(arg1), arg2, sizeof(arg2));

	if (*arg1 && *arg2 && isdigit(*arg1) && isdigit(*arg2))
	{
		BYTE mode;
		WORD flag;

		str_to_number(mode, arg1);
		str_to_number(flag, arg2);

		ch->SetPickupMode(mode);
		ch->SetPickupBlockFlag(flag);
	}
}
#endif // ENABLE_PICKUP_FILTER

[...]
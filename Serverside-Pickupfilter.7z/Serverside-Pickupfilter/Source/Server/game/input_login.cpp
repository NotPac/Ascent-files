[...]

void CInputLogin::Entergame(LPDESC d, const char * data)
{
	[...]
	
#ifdef ENABLE_PICKUP_FILTER
	ch->LoadPickup();
#endif // ENABLE_PICKUP_FILTER
}
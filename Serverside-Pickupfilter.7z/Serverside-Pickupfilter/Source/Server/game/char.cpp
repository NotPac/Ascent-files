[...]

void CHARACTER::SetBlockModeForce(BYTE bFlag)
{
	[...]
}

#ifdef ENABLE_PICKUP_FILTER
void CHARACTER::LoadPickup()
{
	m_pointsInstant.bPickupMode = GetQuestFlag("pickup_filter.mode");
	m_pointsInstant.wPickupBlockFlag = GetQuestFlag("pickup_filter.block");

	ChatPacket(CHAT_TYPE_COMMAND, "setpickupmode %d", m_pointsInstant.bPickupMode);
	ChatPacket(CHAT_TYPE_COMMAND, "setpickupblock %d", m_pointsInstant.wPickupBlockFlag);
}

void CHARACTER::SetPickupMode(BYTE bMode)
{
	m_pointsInstant.bPickupMode = bMode;

	ChatPacket(CHAT_TYPE_COMMAND, "setpickupmode %d", bMode);
	SetQuestFlag("pickup_filter.mode", bMode);
}

void CHARACTER::SetPickupBlockFlag(WORD wFlag)
{
	m_pointsInstant.wPickupBlockFlag = wFlag;

	ChatPacket(CHAT_TYPE_COMMAND, "setpickupblock %d", wFlag);
	SetQuestFlag("pickup_filter.block", wFlag);
}

bool CHARACTER::IsPickupBlockedItem(DWORD dwVnum)
{
	if (!dwVnum)
	{
		return false;
	}

	const TItemTable* table = ITEM_MANAGER::instance().GetTable(dwVnum);
	if (!table)
	{
		return false;
	}

	if (table->bType == ITEM_WEAPON)
	{
		return IsPickupBlocked(PICKUP_BLOCK_WEAPON);
	}
	else if (table->bType == ITEM_ARMOR)
	{
		switch (table->bSubType)
		{
		case ARMOR_BODY:
			return IsPickupBlocked(PICKUP_BLOCK_ARMOR);
		case ARMOR_HEAD:
			return IsPickupBlocked(PICKUP_BLOCK_HEAD);
		case ARMOR_SHIELD:
			return IsPickupBlocked(PICKUP_BLOCK_SHIELD);
		case ARMOR_WRIST:
			return IsPickupBlocked(PICKUP_BLOCK_WRIST);
		case ARMOR_FOOTS:
			return IsPickupBlocked(PICKUP_BLOCK_FOOTS);
		case ARMOR_NECK:
			return IsPickupBlocked(PICKUP_BLOCK_NECK);
		case ARMOR_EAR:
			return IsPickupBlocked(PICKUP_BLOCK_EAR);
		default:
			return false;
		}
	}
	else if (table->bType != ITEM_WEAPON && table->bType != ITEM_ARMOR)
	{
		return IsPickupBlocked(PICKUP_BLOCK_ETC);
	}

	return false;
}
#endif // ENABLE_PICKUP_FILTER
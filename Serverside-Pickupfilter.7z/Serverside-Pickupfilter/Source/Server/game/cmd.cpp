[...]

ACMD(do_setblockmode);
#ifdef ENABLE_PICKUP_FILTER
ACMD(do_setpickupmode);
#endif // ENABLE_PICKUP_FILTER

[...]

	{ "setblockmode",	do_setblockmode,	0,			POS_DEAD,	GM_PLAYER	},
#ifdef ENABLE_PICKUP_FILTER
	{ "setpickupmode",	do_setpickupmode,	0,			POS_DEAD,	GM_PLAYER },
#endif // ENABLE_PICKUP_FILTER

[...]
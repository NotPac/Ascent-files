[...]

#ifdef ENABLE_PICKUP_FILTER
bool CHARACTER::PickupItem(LPITEM item, DWORD dwVID)
{
	if (!item && dwVID)
	{
		item = ITEM_MANAGER::instance().FindByVID(dwVID);
	}
#else
//This should be your old.
bool CHARACTER::PickupItem(DWORD dwVID)
{
	LPITEM item = ITEM_MANAGER::instance().FindByVID(dwVID);
#endif // ENABLE_PICKUP_FILTER

	[...]
	
	if (item->DistanceValid(this))
	{
#ifdef ENABLE_PICKUP_FILTER
		if (!dwVID && IsPickupBlockedItem(item->GetVnum()))
			return false;
#endif // ENABLE_PICKUP_FILTER	
		
		[...]
	}
}
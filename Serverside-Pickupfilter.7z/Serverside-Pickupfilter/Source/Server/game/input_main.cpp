[...]

void CInputMain::ItemMove(LPCHARACTER ch, const char * data)
{
	[...]
}

#ifdef ENABLE_PICKUP_FILTER
struct RangePickupSingle
{
	LPCHARACTER pkCharacter;

	RangePickupSingle(LPCHARACTER _ch) : pkCharacter(_ch)
	{
	}

	bool operator()(LPENTITY pEnt)
	{
		if (pEnt->IsType(ENTITY_ITEM))
		{
			LPITEM item = (LPITEM)pEnt;
			if (!item)
				return false;

			if (!item->DistanceValid(pkCharacter))
				return false;

			return true;
		}

		return false;
	}
};

struct RangePickupAll
{
	LPCHARACTER pkCharacter;

	RangePickupAll(LPCHARACTER ch) : pkCharacter(ch)
	{
	}

	void operator()(LPENTITY pEnt)
	{
		if (!pkCharacter)
			return;

		if (pEnt->IsType(ENTITY_ITEM))
		{
			LPITEM item = (LPITEM)pEnt;
			if (!item)
				return;

			pkCharacter->PickupItem(item);
		}
	}
};
#endif // ENABLE_PICKUP_FILTER

//Replace whole content:
void CInputMain::ItemPickup(LPCHARACTER ch, const char* data)
{
#ifdef ENABLE_PICKUP_FILTER
	if (!ch)
		return;

	LPSECTREE sectree = ch->GetSectree();
	if (!sectree)
		return;

	const TPacketCGItemPickup* pinfo = reinterpret_cast<const TPacketCGItemPickup*>(data);

	if (ch->GetPickupMode() == PICKUP_MODE_SINGLE)
	{
		RangePickupSingle f(ch);
		LPENTITY pEnt = sectree->find_if(f);
		if (!pEnt)
			return;

		LPITEM item = (LPITEM)pEnt;
		if (!item)
			return;

		ch->PickupItem(item, pinfo->vid);
	}
	else if (ch->GetPickupMode() == PICKUP_MODE_ALL)
	{
		if (pinfo->vid)
		{
			ch->PickupItem(nullptr, pinfo->vid);
		}
		else
		{
			RangePickupAll f(ch);
			sectree->ForEachAround(f);
		}
	}
#else
	struct command_item_pickup* pinfo = (struct command_item_pickup*) data;
	if (ch)
		ch->PickupItem(pinfo->vid);
#endif // ENABLE_PICKUP_FILTER
}

[...]
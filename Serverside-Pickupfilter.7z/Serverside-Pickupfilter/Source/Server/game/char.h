[...]

enum EBlockAction
{
	[...]
};

[...]

#ifdef ENABLE_PICKUP_FILTER
enum EPickupModes
{
	PICKUP_MODE_SINGLE,
	PICKUP_MODE_ALL,
};

enum EPickupBlock
{
	PICKUP_BLOCK_WEAPON = (1 << 0),
	PICKUP_BLOCK_ARMOR	= (1 << 1),
	PICKUP_BLOCK_HEAD	= (1 << 2),
	PICKUP_BLOCK_SHIELD = (1 << 3),
	PICKUP_BLOCK_WRIST	= (1 << 4),
	PICKUP_BLOCK_FOOTS	= (1 << 5),
	PICKUP_BLOCK_NECK	= (1 << 6),
	PICKUP_BLOCK_EAR	= (1 << 7),
	PICKUP_BLOCK_ETC	= (1 << 8),
};
#endif // ENABLE_PICKUP_FILTER

[...]

typedef struct character_point_instant
{
	[...]
	
	BYTE			bBlockMode;

#ifdef ENABLE_PICKUP_FILTER
	BYTE			bPickupMode;
	WORD			wPickupBlockFlag;
#endif // ENABLE_PICKUP_FILTER	

	[...]
	
} CHARACTER_POINT_INSTANT;

[...]

		bool			IsBlockMode(BYTE bFlag) const	{ return (m_pointsInstant.bBlockMode & bFlag)?true:false; }

#ifdef ENABLE_PICKUP_FILTER
		void			LoadPickup();
		void			SetPickupMode(BYTE bMode);
		BYTE			GetPickupMode() const { return m_pointsInstant.bPickupMode; };

		void			SetPickupBlockFlag(WORD wFlag);
		bool			IsPickupBlocked(WORD wFlag) const { return (m_pointsInstant.wPickupBlockFlag & wFlag) ? true : false; }
		bool			IsPickupBlockedItem(DWORD dwVnum);
#endif // ENABLE_PICKUP_FILTER

[...]


//Search & Replace:
//		bool			PickupItem(LPITEM item, DWORD vid = 0);

#ifdef ENABLE_PICKUP_FILTER
		bool			PickupItem(LPITEM item, DWORD vid = 0);
#else
		bool			PickupItem(DWORD vid);
#endif // ENABLE_PICKUP_FILTER

[...]

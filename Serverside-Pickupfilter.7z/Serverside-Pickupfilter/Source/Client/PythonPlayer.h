[...]

void	SendClickItemPacket(DWORD dwIID);

#ifdef ENABLE_PICKUP_FILTER
		void	SendPickupItemPacket();
#endif // ENABLE_PICKUP_FILTER

[...]
[...]

void CPythonPlayer::SendClickItemPacket(DWORD dwIID)
{
	[...]
}

#ifdef ENABLE_PICKUP_FILTER
void CPythonPlayer::SendPickupItemPacket()
{
	if (IsObserverMode())
		return;

	static DWORD s_dwNextTCPTime = 0;

	DWORD dwCurTime = ELTimer_GetMSec();

	if (dwCurTime >= s_dwNextTCPTime)
	{
		s_dwNextTCPTime = dwCurTime + 100;

		CPythonNetworkStream& rkNetStream = CPythonNetworkStream::Instance();
		rkNetStream.SendItemPickUpPacket(0);
	}
}
#endif // ENABLE_PICKUP_FILTER
[...]

//Replace whole method or content:

PyObject * playerPickCloseItem(PyObject* poSelf, PyObject* poArgs)
{
#ifdef ENABLE_PICKUP_FILTER
	CPythonPlayer::Instance().SendPickupItemPacket();
#else
	CPythonPlayer::Instance().PickCloseItem();
#endif
	return Py_BuildNone();
}

[...]
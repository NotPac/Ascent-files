	[At the end of file]
	
#ifdef ENABLE_PICKUP_FILTER
	PyModule_AddIntConstant(poModule, "ENABLE_PICKUP_FILTER", 1);
#else
	PyModule_AddIntConstant(poModule, "ENABLE_PICKUP_FILTER", 0);
#endif // ENABLE_PICKUP_FILTER
}
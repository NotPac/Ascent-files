// Arat
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
bool CPythonPlayer::IsBeltInventorySlot(TItemPos Cell)
{
	return Cell.IsBeltInventoryCell();
}
#endif

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
bool CPythonPlayer::IsSkillBookInventorySlot(TItemPos Cell)
{
	return Cell.IsSkillBookInventoryCell();
}

bool CPythonPlayer::IsUpgradeItemsInventorySlot(TItemPos Cell)
{
	return Cell.IsUpgradeItemsInventoryCell();
}

bool CPythonPlayer::IsStoneInventorySlot(TItemPos Cell)
{
	return Cell.IsStoneInventoryCell();
}

bool CPythonPlayer::IsBoxInventorySlot(TItemPos Cell)
{
	return Cell.IsBoxInventoryCell();
}

bool CPythonPlayer::IsEfsunInventorySlot(TItemPos Cell)
{
	return Cell.IsEfsunInventoryCell();
}

bool CPythonPlayer::IsCicekInventorySlot(TItemPos Cell)
{
	return Cell.IsCicekInventoryCell();
}
#endif



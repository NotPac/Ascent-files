// Arat
		bool	IsInventorySlot(TItemPos SlotIndex);
		bool	IsEquipmentSlot(TItemPos SlotIndex);

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
		bool	IsSkillBookInventorySlot(TItemPos Cell);
		bool	IsUpgradeItemsInventorySlot(TItemPos Cell);
		bool	IsStoneInventorySlot(TItemPos Cell);
		bool	IsBoxInventorySlot(TItemPos Cell);
		bool	IsEfsunInventorySlot(TItemPos Cell);
		bool	IsCicekInventorySlot(TItemPos Cell);
#endif
// Arat
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
PyObject * playerIsBeltInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsBeltInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}
#endif

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
PyObject * playerIsSkillBookInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsSkillBookInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}

PyObject * playerIsUpgradeItemsInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsUpgradeItemsInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}

PyObject * playerIsStoneInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsStoneInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}

PyObject * playerIsBoxInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsBoxInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}

PyObject * playerIsEfsunInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsEfsunInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}

PyObject * playerIsCicekInventorySlot(PyObject* poSelf, PyObject* poArgs)
{
	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iSlotIndex))
		return Py_BuildException();

	char Flag = CPythonPlayer::Instance().IsCicekInventorySlot(TItemPos(INVENTORY, iSlotIndex));

	return Py_BuildValue("i", Flag);
}
#endif


// Arat
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
		{ "IsBeltInventorySlot",			playerIsBeltInventorySlot,			METH_VARARGS },
		{ "IsEquippingBelt",				playerIsEquippingBelt,				METH_VARARGS },		
		{ "IsAvailableBeltInventoryCell",	playerIsAvailableBeltInventoryCell,	METH_VARARGS },		
#endif

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
		{ "IsSkillBookInventorySlot",		playerIsSkillBookInventorySlot,		METH_VARARGS },
		{ "IsUpgradeItemsInventorySlot",	playerIsUpgradeItemsInventorySlot,	METH_VARARGS },
		{ "IsStoneInventorySlot",			playerIsStoneInventorySlot,			METH_VARARGS },
		{ "IsBoxInventorySlot",				playerIsBoxInventorySlot,			METH_VARARGS },
		{ "IsEfsunInventorySlot",			playerIsEfsunInventorySlot,			METH_VARARGS },
		{ "IsCicekInventorySlot",			playerIsCicekInventorySlot,			METH_VARARGS },
#endif

// Arat
	PyModule_AddIntConstant(poModule, "MBS_CLICK",	CPythonPlayer::MBS_CLICK);
	PyModule_AddIntConstant(poModule, "MBT_RIGHT",	CPythonPlayer::MBT_RIGHT);
	PyModule_AddIntConstant(poModule, "MBT_LEFT",	CPythonPlayer::MBT_LEFT);

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	PyModule_AddIntConstant(poModule, "SKILL_BOOK_INVENTORY_SLOT_COUNT",	c_Skill_Book_Inventory_Slot_Count);
	PyModule_AddIntConstant(poModule, "UPGRADE_ITEMS_INVENTORY_SLOT_COUNT",	c_Upgrade_Items_Inventory_Slot_Count);
	PyModule_AddIntConstant(poModule, "STONE_INVENTORY_SLOT_COUNT",	c_Stone_Inventory_Slot_Count);
	PyModule_AddIntConstant(poModule, "BOX_INVENTORY_SLOT_COUNT",	c_Box_Inventory_Slot_Count);
	PyModule_AddIntConstant(poModule, "EFSUN_INVENTORY_SLOT_COUNT",	c_Efsun_Inventory_Slot_Count);
	PyModule_AddIntConstant(poModule, "CICEK_INVENTORY_SLOT_COUNT",	c_Cicek_Inventory_Slot_Count);
#endif

// Arat
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_PRIVATE_SHOP",				SLOT_TYPE_PRIVATE_SHOP);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_MALL",						SLOT_TYPE_MALL);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_EMOTION",					SLOT_TYPE_EMOTION);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_DRAGON_SOUL_INVENTORY",	SLOT_TYPE_DRAGON_SOUL_INVENTORY);

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_SKILL_BOOK_INVENTORY",		SLOT_TYPE_SKILL_BOOK_INVENTORY);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_UPGRADE_ITEMS_INVENTORY",	SLOT_TYPE_UPGRADE_ITEMS_INVENTORY);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_STONE_INVENTORY",			SLOT_TYPE_STONE_INVENTORY);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_BOX_INVENTORY",			SLOT_TYPE_BOX_INVENTORY);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_EFSUN_INVENTORY",			SLOT_TYPE_EFSUN_INVENTORY);
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_CICEK_INVENTORY",			SLOT_TYPE_CICEK_INVENTORY);
#endif
// Arat
				if (false == cell.IsDefaultInventoryPosition() && false == cell.IsBeltInventoryPosition()

// De�i�tir - https://prnt.sc/qaqoxu
				if (false == cell.IsDefaultInventoryPosition() && false == cell.IsBeltInventoryPosition()
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
					&& false == cell.IsSkillBookInventoryPosition() && false == cell.IsUpgradeItemsInventoryPosition()
					&& false == cell.IsStoneInventoryPosition() && false == cell.IsBoxInventoryPosition()
					&& false == cell.IsEfsunInventoryPosition() && false == cell.IsCicekInventoryPosition()
#endif
					)

// Arat
bool CItem::IsSameSpecialGroup(const LPITEM item) const
{
	// ���� VNUM�� ���ٸ� ���� �׷��� ������ ����
	if (this->GetVnum() == item->GetVnum())
		return true;

	if (GetSpecialGroup() && (item->GetSpecialGroup() == GetSpecialGroup()))
		return true;

	return false;
}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
bool CItem::IsSkillBook()
{
	return (GetVnum() == 50300);
}

bool CItem::IsUpgradeItem()
{
	switch (GetVnum())
	{
		case 30003:
		case 30004:
		case 30005:
		case 30006:
		case 30007:
		case 30008:
		case 30009:
		case 30010:
		case 30011:
		case 30014:
		case 30015:
		case 30016:
		case 30017:
		case 30018:
		case 30019:
		case 30021:
		case 30022:
		case 30023:
		case 30025:
		case 30027:
		case 30028:
		case 30030:
		case 30031:
		case 30032:
		case 30033:
		case 30034:
		case 30035:
		case 30037:
		case 30038:
		case 30039:
		case 30040:
		case 30041:
		case 30042:
		case 30045:
		case 30046:
		case 30047:
		case 30048:
		case 30049:
		case 30050:
		case 30051:
		case 30052:
		case 30053:
		case 30055:
		case 30056:
		case 30057:
		case 30058:
		case 30059:
		case 30060:
		case 30061:
		case 30067:
		case 30069:
		case 30070:
		case 30071:
		case 30072:
		case 30073:
		case 30074:
		case 30075:
		case 30076:
		case 30077:
		case 30078:
		case 30079:
		case 30080:
		case 30081:
		case 30082:
		case 30083:
		case 30084:
		case 30085:
		case 30086:
		case 30087:
		case 30088:
		case 30089:
		case 30090:
		case 30091:
		case 30092:
		case 30192:
		case 30193:
		case 30194:
		case 30195:
		case 30196:
		case 30197:
		case 30198:
		case 30199:
		case 30500:
		case 30501:
		case 30502:
		case 30503:
		case 30504:
		case 30505:
		case 30506:
		case 30507:
		case 30508:
		case 30509:
		case 30510:
		case 30511:
		case 30512:
		case 30513:
		case 30514:
		case 30515:
		case 30516:
		case 30517:
		case 30518:
		case 30519:
		case 30520:
		case 30521:
		case 30522:
		case 30523:
		case 30524:
		case 30525:
		case 30600:
		case 30601:
		case 30602:
		case 30603:
		case 30604:
		case 30605:
		case 30606:
		case 30607:
		case 30608:
		case 30609:
		case 30610:
		case 30611:
		case 30612:
		case 30614:
		case 30615:
		case 30616:
		case 30617:
		case 30618:
		case 30619:
		case 30620:
		case 30621:
		case 30622:
		case 30623:
		case 30624:
		case 30625:
		case 30626:
		case 30627:
		case 30628:
		case 30629:
		case 27992:
		case 27993:
		case 27994:
		case 71123:
		case 71129:
		case 31108:
		case 31109:
		case 31110:
		case 31111:
		case 31112:
		case 31113:
		case 31114:
		case 31115:
		case 31117:
		case 31118:
		case 31120:
		case 31121:
		case 31122:
		case 31123:
		case 31124:
		case 31125:
		case 31126:
		case 31127:
		case 31128:
		case 31129:
		case 31130:
		case 31131:
		case 31132:
		case 31133:
		case 31134:
		case 31135:
		case 31136:
		case 31137:
		case 31138:
		case 31144:
		case 31145:
		case 31146:
		case 31148:
		case 31149:
		case 31196:
		case 31197:
		case 31198:
		case 31199:
		case 31200:
		case 31201:
		case 31202:
		case 31203:
		case 31204:
		case 31205:
		case 31206:
		case 31207:
		case 31208:
		case 31209:
		case 31210:
		case 31211:
		case 31212:
		case 31213:
		case 31372:
		case 31378:
		case 31380:
		case 244120:
		case 244121:
			return true;
	}
	return false;
}

bool CItem::IsStone()
{
	return GetType() == ITEM_METIN;
}

bool CItem::IsBox()
{
	return GetType() == ITEM_GIFTBOX
	&& GetVnum() != 50187 && GetVnum() != 50188 && GetVnum() != 50189
	&& GetVnum() != 50190 && GetVnum() != 50191 && GetVnum() != 50192
	&& GetVnum() != 50193 && GetVnum() != 50194 && GetVnum() != 50195
	&& GetVnum() != 50196 && GetVnum() != 50197 && GetVnum() != 50255
	&& GetVnum() != 50256 && GetVnum() != 50257 && GetVnum() != 50258
	&& GetVnum() != 50259 && GetVnum() != 50260 && GetVnum() != 51504
	&& GetVnum() != 51510;
}

bool CItem::IsEfsun()
{
	switch (GetVnum())
	{
		case 71084:
		case 71085:
		case 70024:
		case 72304:
		case 76015:
		case 39004:
		case 39028:
		case 39029:
		case 71151:
		case 71152:
		case 76023:
		case 76024:
			return true;
	}
	return false;
}

bool CItem::IsCicek()
{
	switch (GetVnum())
	{
		case 50721:
		case 50722:
		case 50723:
		case 50724:
		case 50725:
		case 50726:
		case 50727:
		case 50728:
			return true;
	}
	return false;
}
#endif

// Arat
			switch (p->window)
			{
				case INVENTORY:
				case DRAGON_SOUL_INVENTORY:

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
				case SKILL_BOOK_INVENTORY:
				case UPGRADE_ITEMS_INVENTORY:
				case STONE_INVENTORY:
				case BOX_INVENTORY:
				case EFSUN_INVENTORY:
				case CICEK_INVENTORY:
#endif
// Arat
bool CExchange::CheckSpace()
{
	static CGrid s_grid1(INVENTORY_PAGE_COLUMN, INVENTORY_PAGE_ROW);
	static CGrid s_grid2(INVENTORY_PAGE_COLUMN, INVENTORY_PAGE_ROW);
	static CGrid s_grid3(INVENTORY_PAGE_COLUMN, INVENTORY_PAGE_ROW);
	static CGrid s_grid4(INVENTORY_PAGE_COLUMN, INVENTORY_PAGE_ROW);

// Alt�na Eklenir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	LPCHARACTER	me = GetOwner();
	static CGrid s_grid5(5, SKILL_BOOK_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid6(5, SKILL_BOOK_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid7(5, SKILL_BOOK_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid8(5, UPGRADE_ITEMS_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid9(5, UPGRADE_ITEMS_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid10(5, UPGRADE_ITEMS_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid11(5, STONE_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid12(5, STONE_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid13(5, STONE_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid14(5, BOX_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid15(5, BOX_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid16(5, BOX_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid17(5, EFSUN_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid18(5, EFSUN_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid19(5, EFSUN_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid20(5, CICEK_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid21(5, CICEK_INVENTORY_MAX_NUM / 5 / 3);
	static CGrid s_grid22(5, CICEK_INVENTORY_MAX_NUM / 5 / 3);
#endif

// Arat
	s_grid1.Clear();
	s_grid2.Clear();
	s_grid3.Clear();
	s_grid4.Clear();

// Alt�na Eklenir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	s_grid5.Clear();
	s_grid6.Clear();
	s_grid7.Clear();
	s_grid8.Clear();
	s_grid9.Clear();
	s_grid10.Clear();
	s_grid11.Clear();
	s_grid12.Clear();
	s_grid13.Clear();
	s_grid14.Clear();
	s_grid15.Clear();
	s_grid16.Clear();
	s_grid17.Clear();
	s_grid18.Clear();
	s_grid19.Clear();
	s_grid20.Clear();
	s_grid21.Clear();
	s_grid22.Clear();
#endif

// Arat
	// ��... ���� ������ ������... ��ȥ�� �κ��� ��� �κ� ���� ���� ���� �� �߸��̴� �Ф�
	static std::vector <WORD> s_vDSGrid(DRAGON_SOUL_INVENTORY_MAX_NUM);

	// �ϴ� ��ȥ���� ��ȯ���� ���� ���ɼ��� ũ�Ƿ�, ��ȥ�� �κ� ����� ��ȥ���� ���� �� �ϵ��� �Ѵ�.
	bool bDSInitialized = false;

// �st�ne Eklenir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	int b;
	int v;
	int u;
	int r;
	int a;
	int l;
	const int perPageSkillBookSlotCount = 45;
	const int perPageUpgradeItemsSlotCount = 45;
	const int perPageStoneSlotCount = 45;
	const int perPageBoxSlotCount = 45;
	const int perPageEfsunSlotCount = 45;
	const int perPageCicekSlotCount = 45;
	for (b = 0; b < SKILL_BOOK_INVENTORY_MAX_NUM; ++b) {
		if (!(item = me->GetSkillBookInventoryItem(b)))
			continue;
		
		BYTE itemSize = item->GetSize();
			
		if (i < perPageSkillBookSlotCount) // Notice: This is adjusted for 3 Pages only!
			s_grid5.Put(i, 1, itemSize);
		else if (i < perPageSkillBookSlotCount * 2)
			s_grid6.Put(i - perPageSkillBookSlotCount, 1, itemSize);
		else if (i < perPageSkillBookSlotCount * 3)
			s_grid7.Put(i - perPageSkillBookSlotCount * 2, 1, itemSize);
	}
	
	for (v = 0; v < UPGRADE_ITEMS_INVENTORY_MAX_NUM; ++v) {
		if (!(item = me->GetUpgradeItemsInventoryItem(v)))
			continue;
		
		BYTE itemSize = item->GetSize();
		
		if (i < perPageUpgradeItemsSlotCount) // Notice: This is adjusted for 3 Pages only!
			s_grid8.Put(i, 1, itemSize);
		else if (i < perPageUpgradeItemsSlotCount * 2)
			s_grid9.Put(i - perPageUpgradeItemsSlotCount, 1, itemSize);
		else if (i < perPageUpgradeItemsSlotCount * 3)
			s_grid10.Put(i - perPageUpgradeItemsSlotCount * 2, 1, itemSize);
	}
	
	for (u = 0; u < STONE_INVENTORY_MAX_NUM; ++u) {
		if (!(item = me->GetStoneInventoryItem(u)))
			continue;
		
		BYTE itemSize = item->GetSize();
		
		if (i < perPageStoneSlotCount) // Notice: This is adjusted for 3 Pages only!
			s_grid11.Put(i, 1, itemSize);
		else if (i < perPageStoneSlotCount * 2)
			s_grid12.Put(i - perPageStoneSlotCount, 1, itemSize);
		else if (i < perPageStoneSlotCount * 3)
			s_grid13.Put(i - perPageStoneSlotCount * 2, 1, itemSize);
	}
	
	for (r = 0; r < BOX_INVENTORY_MAX_NUM; ++r) {
		if (!(item = me->GetBoxInventoryItem(r)))
			continue;
		
		BYTE itemSize = item->GetSize();
		
		if (i < perPageBoxSlotCount) // Notice: This is adjusted for 3 Pages only!
			s_grid14.Put(i, 1, itemSize);
		else if (i < perPageBoxSlotCount * 2)
			s_grid15.Put(i - perPageBoxSlotCount, 1, itemSize);
		else if (i < perPageBoxSlotCount * 3)
			s_grid16.Put(i - perPageBoxSlotCount * 2, 1, itemSize);
	}
	
	for (a = 0; a < EFSUN_INVENTORY_MAX_NUM; ++a) {
		if (!(item = me->GetEfsunInventoryItem(a)))
			continue;
		
		BYTE itemSize = item->GetSize();
		
		if (i < perPageEfsunSlotCount) // Notice: This is adjusted for 3 Pages only!
			s_grid17.Put(i, 1, itemSize);
		else if (i < perPageEfsunSlotCount * 2)
			s_grid18.Put(i - perPageEfsunSlotCount, 1, itemSize);
		else if (i < perPageEfsunSlotCount * 3)
			s_grid19.Put(i - perPageEfsunSlotCount * 2, 1, itemSize);
	}
	
	for (l = 0; l < CICEK_INVENTORY_MAX_NUM; ++l) {
		if (!(item = me->GetCicekInventoryItem(l)))
			continue;
		
		BYTE itemSize = item->GetSize();
		
		if (i < perPageCicekSlotCount) // Notice: This is adjusted for 3 Pages only!
			s_grid20.Put(i, 1, itemSize);
		else if (i < perPageCicekSlotCount * 2)
			s_grid21.Put(i - perPageCicekSlotCount, 1, itemSize);
		else if (i < perPageCicekSlotCount * 3)
			s_grid22.Put(i - perPageCicekSlotCount * 2, 1, itemSize);
	}
#endif


// Arat
		else
		{
			int iPos;

			if ((iPos = s_grid1.FindBlank(1, item->GetSize())) >= 0)
			{
				s_grid1.Put(iPos, 1, item->GetSize());
			}
			else if ((iPos = s_grid2.FindBlank(1, item->GetSize())) >= 0)
			{
				s_grid2.Put(iPos, 1, item->GetSize());

// �st�ne Eklenir - https://prnt.sc/qaqnvn
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
		{
			BYTE itemSize = item->GetSize();
			int iPos = s_grid5.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid5.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid6.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid6.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid7.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid7.Put(iPos, 1, itemSize);
				continue;
			}
			
			return false;
		}
		else if (item->IsUpgradeItem())
		{
			BYTE itemSize = item->GetSize();
			int iPos = s_grid8.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid8.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid9.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid9.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid10.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid10.Put(iPos, 1, itemSize);
				continue;
			}
			
			return false;
		}
		else if (item->IsStone())
		{
			BYTE itemSize = item->GetSize();
			int iPos = s_grid11.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid11.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid12.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid12.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid13.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid13.Put(iPos, 1, itemSize);
				continue;
			}
			
			return false;
		}
		else if (item->IsBox())
		{
			BYTE itemSize = item->GetSize();
			int iPos = s_grid14.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid14.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid15.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid15.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid16.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid16.Put(iPos, 1, itemSize);
				continue;
			}
			
			return false;
		}
		else if (item->IsEfsun())
		{
			BYTE itemSize = item->GetSize();
			int iPos = s_grid17.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid17.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid18.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid18.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid19.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid19.Put(iPos, 1, itemSize);
				continue;
			}
			
			return false;
		}
		else if (item->IsCicek())
		{
			BYTE itemSize = item->GetSize();
			int iPos = s_grid20.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid20.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid21.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid21.Put(iPos, 1, itemSize);
				continue;
			}
			
			iPos = s_grid22.FindBlank(1, itemSize);
			if (iPos >= 0) {
				s_grid22.Put(iPos, 1, itemSize);
				continue;
			}
			
			return false;
		}
#endif

// Arat bool CExchange::Done() ��inde
		if (item->IsDragonSoul())
			empty_pos = victim->GetEmptyDragonSoulInventory(item);

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
			empty_pos = victim->GetEmptySkillBookInventory(item->GetSize());
		else if (item->IsUpgradeItem())
			empty_pos = victim->GetEmptyUpgradeItemsInventory(item->GetSize());
		else if (item->IsStone())
			empty_pos = victim->GetEmptyStoneInventory(item->GetSize());
		else if (item->IsBox())
			empty_pos = victim->GetEmptyBoxInventory(item->GetSize());
		else if (item->IsEfsun())
			empty_pos = victim->GetEmptyEfsunInventory(item->GetSize());
		else if (item->IsCicek())
			empty_pos = victim->GetEmptyCicekInventory(item->GetSize());
#endif

// Arat bool CExchange::Done() ��inde
		item->RemoveFromCharacter();
		if (item->IsDragonSoul())
			item->AddToCharacter(victim, TItemPos(DRAGON_SOUL_INVENTORY, empty_pos));

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
			item->AddToCharacter(victim, TItemPos(INVENTORY, empty_pos));
		else if (item->IsUpgradeItem())
			item->AddToCharacter(victim, TItemPos(INVENTORY, empty_pos));
		else if (item->IsStone())
			item->AddToCharacter(victim, TItemPos(INVENTORY, empty_pos));
		else if (item->IsBox())
			item->AddToCharacter(victim, TItemPos(INVENTORY, empty_pos));
		else if (item->IsEfsun())
			item->AddToCharacter(victim, TItemPos(INVENTORY, empty_pos));
		else if (item->IsCicek())
			item->AddToCharacter(victim, TItemPos(INVENTORY, empty_pos));
#endif
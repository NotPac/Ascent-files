// Arat
	BYTE			bItemGrid[INVENTORY_AND_EQUIP_SLOT_MAX];
	LPITEM			pItems[INVENTORY_AND_EQUIP_SLOT_MAX];

// De�i�tir - https://prnt.sc/qaqh20
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
#include "../../common/service.h"
	UINT			bItemGrid[INVENTORY_AND_EQUIP_SLOT_MAX];
	LPITEM			pItems[INVENTORY_AND_EQUIP_SLOT_MAX];
#else
	BYTE			bItemGrid[INVENTORY_AND_EQUIP_SLOT_MAX];
	LPITEM			pItems[INVENTORY_AND_EQUIP_SLOT_MAX];
#endif

// Arat
		void			SetItem(TItemPos Cell, LPITEM item);
		LPITEM			GetItem(TItemPos Cell) const;
		LPITEM			GetInventoryItem(WORD wCell) const;

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		LPITEM			GetSkillBookInventoryItem(WORD wCell) const;
		LPITEM			GetUpgradeItemsInventoryItem(WORD wCell) const;
		LPITEM			GetStoneInventoryItem(WORD wCell) const;
		LPITEM			GetBoxInventoryItem(WORD wCell) const;
		LPITEM			GetEfsunInventoryItem(WORD wCell) const;
		LPITEM			GetCicekInventoryItem(WORD wCell) const;
#endif

// Arat
		int				GetEmptyInventory(BYTE size) const;
		int				GetEmptyDragonSoulInventory(LPITEM pItem) const;

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		int				GetEmptySkillBookInventory(BYTE size) const;
		int				GetEmptyUpgradeItemsInventory(BYTE size) const;
		int				GetEmptyStoneInventory(BYTE size) const;
		int				GetEmptyBoxInventory(BYTE size) const;
		int				GetEmptyEfsunInventory(BYTE size) const;
		int				GetEmptyCicekInventory(BYTE size) const;
#endif
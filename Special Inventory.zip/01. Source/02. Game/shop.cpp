// Arat
	if (m_pkPC) // �Ǿ��� ��ϴ� ���� �Ǿ��� ���� �������� �������־�� �Ѵ�.
		item = r_item.pkItem;
	else
		item = ITEM_MANAGER::instance().CreateItem(r_item.vnum, r_item.count);

	if (!item)
		return SHOP_SUBHEADER_GC_SOLD_OUT;

	int iEmptyPos;
	if (item->IsDragonSoul())
	{
		iEmptyPos = ch->GetEmptyDragonSoulInventory(item);
	}

// Ekle - https://prnt.sc/qaqpj0
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	else if (item->IsSkillBook())
	{
		iEmptyPos = ch->GetEmptySkillBookInventory(item->GetSize());
	}
	else if (item->IsUpgradeItem())
	{
		iEmptyPos = ch->GetEmptyUpgradeItemsInventory(item->GetSize());
	}
	else if (item->IsStone())
	{
		iEmptyPos = ch->GetEmptyStoneInventory(item->GetSize());
	}
	else if (item->IsBox())
	{
		iEmptyPos = ch->GetEmptyBoxInventory(item->GetSize());
	}
	else if (item->IsEfsun())
	{
		iEmptyPos = ch->GetEmptyEfsunInventory(item->GetSize());
	}
	else if (item->IsCicek())
	{
		iEmptyPos = ch->GetEmptyCicekInventory(item->GetSize());
	}
#endif

// Arat
			if (item->GetVnum() >= 80003 && item->GetVnum() <= 80007)
			{
				snprintf(buf, sizeof(buf), "%s FROM: %u TO: %u PRICE: %u", item->GetName(), ch->GetPlayerID(), m_pkPC->GetPlayerID(), dwPrice);
				LogManager::instance().GoldBarLog(ch->GetPlayerID(), item->GetID(), SHOP_BUY, buf);
				LogManager::instance().GoldBarLog(m_pkPC->GetPlayerID(), item->GetID(), SHOP_SELL, buf);
			}

			item->RemoveFromCharacter();
			if (item->IsDragonSoul())
				item->AddToCharacter(ch, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyPos));

// Ekle 
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
			else if (item->IsSkillBook())
				item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
			else if (item->IsUpgradeItem())
				item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
			else if (item->IsStone())
				item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
			else if (item->IsBox())
				item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
			else if (item->IsEfsun())
				item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
			else if (item->IsCicek())
				item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
#endif

// Arat
		if (iVal > 0)
			m_pkPC->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�Ǹűݾ��� %d %% �� �������� �����Ե˴ϴ�"), iVal);

		CMonarch::instance().SendtoDBAddMoney(dwTax, m_pkPC->GetEmpire(), m_pkPC);
	}
	else
	{
		if (item->IsDragonSoul())
			item->AddToCharacter(ch, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyPos));

// Ekle https://prnt.sc/qaqq9b
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
			item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
		else if (item->IsUpgradeItem())
			item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
		else if (item->IsStone())
			item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
		else if (item->IsBox())
			item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
		else if (item->IsEfsun())
			item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
		else if (item->IsCicek())
			item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
#endif
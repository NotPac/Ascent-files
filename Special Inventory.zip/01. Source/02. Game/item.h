// Arat
		bool		IsDragonSoul();
		int		GiveMoreTime_Per(float fPercent);
		int		GiveMoreTime_Fix(DWORD dwTime);

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		bool		IsSkillBook();
		bool		IsUpgradeItem();
		bool		IsStone();
		bool		IsBox();
		bool		IsEfsun();
		bool		IsCicek();
#endif
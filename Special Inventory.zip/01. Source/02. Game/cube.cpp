// Arat
	if (inven_index<0 || INVENTORY_MAX_NUM<=inven_index)
		return;

// De�i�tir
	if (inven_index<0 || INVENTORY_AND_EQUIP_SLOT_MAX<=inven_index)
		return;
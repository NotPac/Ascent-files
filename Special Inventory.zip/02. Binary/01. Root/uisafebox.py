# Ara
			if player.SLOT_TYPE_INVENTORY == mouseModule.mouseController.GetAttachedType()

#De�i�
			if player.SLOT_TYPE_INVENTORY == mouseModule.mouseController.GetAttachedType() or player.SLOT_TYPE_SKILL_BOOK_INVENTORY == mouseModule.mouseController.GetAttachedType() or player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY == mouseModule.mouseController.GetAttachedType() or player.SLOT_TYPE_STONE_INVENTORY == mouseModule.mouseController.GetAttachedType() or player.SLOT_TYPE_BOX_INVENTORY == mouseModule.mouseController.GetAttachedType() or player.SLOT_TYPE_EFSUN_INVENTORY == mouseModule.mouseController.GetAttachedType() or player.SLOT_TYPE_CICEK_INVENTORY == mouseModule.mouseController.GetAttachedType():

#Ara
			if player.SLOT_TYPE_INVENTORY == attachedSlotType

#De�i�
			if player.SLOT_TYPE_INVENTORY == attachedSlotType or player.SLOT_TYPE_SKILL_BOOK_INVENTORY == attachedSlotType or player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY == attachedSlotType or player.SLOT_TYPE_STONE_INVENTORY == attachedSlotType or player.SLOT_TYPE_BOX_INVENTORY == attachedSlotType or player.SLOT_TYPE_EFSUN_INVENTORY == attachedSlotType or player.SLOT_TYPE_CICEK_INVENTORY == attachedSlotType:
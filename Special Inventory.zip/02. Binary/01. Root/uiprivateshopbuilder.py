# Ara
			if (player.SLOT_TYPE_INVENTORY != attachedSlotType

#De�i�
			if (player.SLOT_TYPE_INVENTORY != attachedSlotType and player.SLOT_TYPE_DRAGON_SOUL_INVENTORY != attachedSlotType and player.SLOT_TYPE_SKILL_BOOK_INVENTORY != attachedSlotType and player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY != attachedSlotType and player.SLOT_TYPE_STONE_INVENTORY != attachedSlotType and player.SLOT_TYPE_BOX_INVENTORY != attachedSlotType and player.SLOT_TYPE_EFSUN_INVENTORY != attachedSlotType and player.SLOT_TYPE_CICEK_INVENTORY != attachedSlotType):

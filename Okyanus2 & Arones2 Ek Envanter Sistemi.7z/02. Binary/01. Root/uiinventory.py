# �mportlar aras�na ekle
import uiPickEtc

# Arat
	def RefreshCostumeSlot(self):
		getItemVNum=player.GetItemIndex
		
		for i in xrange(item.COSTUME_SLOT_COUNT):
			slotNumber = item.COSTUME_SLOT_START + i
			self.wndEquip.SetItemSlot(slotNumber, getItemVNum(slotNumber), 0)

		self.wndEquip.RefreshSlot()

# Alt�na ekle
if app.WJ_SPLIT_INVENTORY_SYSTEM:
	class ExtendedInventoryWindow(ui.ScriptWindow):
		tooltipItem = None
		interface = None
		dlgPickMoney = None
		dlgPickItem = None
		sellingSlotNumber = -1
		isLoaded = 0
		
		def __init__(self):
			ui.ScriptWindow.__init__(self)
			self.inventoryPageIndex = 0
			self.__LoadWindow()
			
		def __del__(self):
			ui.ScriptWindow.__del__(self)


		def Show(self):
			self.__LoadWindow()
			ui.ScriptWindow.Show(self)	
			
		def BindInterfaceClass(self, interface):
			self.interface = interface

		def __LoadWindow(self):
			if self.isLoaded == 1:
				return

			self.isLoaded = 1
			
			try:
				pyScrLoader = ui.PythonScriptLoader()
				pyScrLoader.LoadScriptFile(self, "UIScript/ExtendedInventoryWindow.py")
			except:
				import exception
				exception.Abort("ExtendedInventoryWindow.LoadWindow.LoadObject")

			try:
				wndItem = self.GetChild("ItemSlot")
				self.GetChild("TitleBar").SetCloseEvent(ui.__mem_func__(self.Close))
				self.titleName = self.GetChild("TitleName")
				self.SkillBookButton = self.GetChild("SkillBookButton")
				self.UpgradeItemsButton = self.GetChild("UpgradeItemsButton")
				self.stoneButton = self.GetChild("StoneButton")
				self.boxButton = self.GetChild("BoxButton")
				self.efsunButton = self.GetChild("EfsunButton")
				self.cicekButton = self.GetChild("CicekButton")
				self.inventoryTab = []
				self.inventoryTab.append(self.GetChild("Inventory_Tab_01"))
				self.inventoryTab.append(self.GetChild("Inventory_Tab_02"))
				self.inventoryTab.append(self.GetChild("Inventory_Tab_03"))
				self.MalzemeDeposuInfo = self.GetChild("MalzemeDeposuInfo")
			except:
				import exception
				exception.Abort("ExtendedInventoryWindow.LoadWindow.BindObject")

			## Info
			self.tlInfo = uiToolTip.ItemToolTip()
			self.tlInfo.Hide()
			self.tooltipInfo = [self.tlInfo]*7
			self.InformationText = [localeInfo.MALZEME_DEPOSU,
									localeInfo.BK_ENVANTER_TEXT1,
									localeInfo.BK_ENVANTER_TEXT2,
									localeInfo.BK_ENVANTER_TEXT3,
									localeInfo.BK_ENVANTER_TEXT4,
									localeInfo.BK_ENVANTER_TEXT5,
									localeInfo.BK_ENVANTER_TEXT6
			]
			
			for i in xrange(7):
				self.tooltipInfo[i].SetFollow(True)
				self.tooltipInfo[i].AlignHorizonalCenter()
				if i == 0:
					TITLE_COLOR = grp.GenerateColor(0.9490, 0.9058, 0.7568, 1.0)
					self.tooltipInfo[i].AutoAppendTextLine(self.InformationText[i], TITLE_COLOR)
				else:
					self.tooltipInfo[i].AutoAppendTextLine(self.InformationText[i])
				self.tooltipInfo[i].Hide()
				self.tooltipInfo[i].toolTipWidth += 10

			## Item
			wndItem.SetSelectEmptySlotEvent(ui.__mem_func__(self.SelectEmptySlot))
			wndItem.SetSelectItemSlotEvent(ui.__mem_func__(self.SelectItemSlot))
			wndItem.SetUnselectItemSlotEvent(ui.__mem_func__(self.UseItemSlot))
			wndItem.SetUseSlotEvent(ui.__mem_func__(self.UseItemSlot))
			wndItem.SetOverInItemEvent(ui.__mem_func__(self.OverInItem))
			wndItem.SetOverOutItemEvent(ui.__mem_func__(self.OverOutItem))

			self.envanterileacilsin = ui.CheckBox()
			self.envanterileacilsin.SetParent(self)
			self.envanterileacilsin.SetPosition(17, 385)
			self.envanterileacilsin.SetEvent(ui.__mem_func__(self.__OnClickEnableEnvanterOn), "ON_CHECK", True)
			self.envanterileacilsin.SetEvent(ui.__mem_func__(self.__OnClickDisableEnvanterOf), "ON_UNCKECK", False)
			self.envanterileacilsin.SetTextInfo(localeInfo.ENVANTER_ILE_AC)
			self.envanterileacilsin.SetCheckStatus(constInfo.EnvanterAcilsinmi)
			self.envanterileacilsin.Show()

			self.SkillBookButton.SetEvent(lambda arg=0: self.SetInventoryType(arg))
			self.UpgradeItemsButton.SetEvent(lambda arg=1: self.SetInventoryType(arg))
			self.stoneButton.SetEvent(lambda arg=2: self.SetInventoryType(arg))
			self.boxButton.SetEvent(lambda arg=3: self.SetInventoryType(arg))
			self.efsunButton.SetEvent(lambda arg=4: self.SetInventoryType(arg))
			self.cicekButton.SetEvent(lambda arg=5: self.SetInventoryType(arg))
			self.SkillBookButton.Down()

			self.inventoryTab[0].SetEvent(lambda arg=0: self.SetInventoryPage(arg))
			self.inventoryTab[1].SetEvent(lambda arg=1: self.SetInventoryPage(arg))
			self.inventoryTab[2].SetEvent(lambda arg=2: self.SetInventoryPage(arg))
			self.inventoryTab[0].Down()
			
			## PickMoneyDialog
			dlgPickMoney = uiPickMoney.PickMoneyDialog()
			dlgPickMoney.LoadDialog()
			dlgPickMoney.Hide()

			## PickItemDialog
			dlgPickItem = uiPickEtc.PickEtcDialog()
			dlgPickItem.LoadDialog()
			dlgPickItem.Hide()
			
			self.dlgPickMoney = dlgPickMoney
			
			self.wndItem = wndItem
			self.SetInventoryType(0)
			self.SetInventoryPage(0)

			self.dlgPickItem = dlgPickItem

			self.wndCostume = None
			
		def Destroy(self):
			self.ClearDictionary()
			self.dlgPickMoney.Destroy()
			self.dlgPickItem.Destroy()
			self.dlgPickItem = 0
			self.dlgPickMoney = 0
			self.tooltipItem = None
			self.wndItem = 0
			self.interface = None
			self.inventoryTab = []
			self.envanterileacilsin = []

		def __OnClickEnableEnvanterOn(self):
			constInfo.EnvanterAcilsinmi = 1
			chat.AppendChat(chat.CHAT_TYPE_INFO, "<Sistem> Envanter ile a��lma aktif.")

		def __OnClickDisableEnvanterOf(self):
			constInfo.EnvanterAcilsinmi = 0
			chat.AppendChat(chat.CHAT_TYPE_INFO, "<Sistem> Envanter ile a��lma pasif.")

		def Hide(self):
			if None != self.tooltipItem:
				self.tooltipItem.HideToolTip()
				self.tlInfo.Hide()
			if self.dlgPickItem:
				self.dlgPickItem.Close()
			wndMgr.Hide(self.hWnd)
			
		def Close(self):
			if self.tooltipItem:
				self.tooltipItem.HideToolTip()
			self.tlInfo.Hide()
			self.Hide()

		def OnUpdate(self):
			for i in xrange(7):
				if self.MalzemeDeposuInfo.IsIn():
					self.tooltipInfo[i].Show()
				else:
					self.tooltipInfo[i].Hide()

		def SetInventoryType(self, type):
			self.inventoryType = type
			if type == 0:
				self.SkillBookButton.Down()
				self.efsunButton.SetUp()
				self.cicekButton.SetUp()
				self.UpgradeItemsButton.SetUp()
				self.stoneButton.SetUp()
				self.boxButton.SetUp()
				self.titleName.SetText(localeInfo.INVENTORY_SKILL_BOOK_TOOLTIP)
			elif type == 2:
				self.stoneButton.Down()
				self.efsunButton.SetUp()
				self.cicekButton.SetUp()
				self.UpgradeItemsButton.SetUp()
				self.SkillBookButton.SetUp()
				self.boxButton.SetUp()
				self.titleName.SetText(localeInfo.INVENTORY_STONE_TOOLTIP)
			elif type == 3:
				self.boxButton.Down()
				self.efsunButton.SetUp()
				self.UpgradeItemsButton.SetUp()
				self.cicekButton.SetUp()
				self.stoneButton.SetUp()
				self.SkillBookButton.SetUp()
				self.titleName.SetText(localeInfo.INVENTORY_BOX_TOOLTIP)
			elif type == 4:
				self.efsunButton.Down()
				self.boxButton.SetUp()
				self.cicekButton.SetUp()
				self.UpgradeItemsButton.SetUp()
				self.stoneButton.SetUp()
				self.SkillBookButton.SetUp()
				self.titleName.SetText(localeInfo.INVENTORY_EFSUN_TOOLTIP)
			elif type == 5:
				self.cicekButton.Down()
				self.efsunButton.SetUp()
				self.boxButton.SetUp()
				self.UpgradeItemsButton.SetUp()
				self.stoneButton.SetUp()
				self.SkillBookButton.SetUp()
				self.titleName.SetText(localeInfo.INVENTORY_CICEK_TOOLTIP)
			else:
				self.UpgradeItemsButton.Down()
				self.SkillBookButton.SetUp()
				self.efsunButton.SetUp()
				self.cicekButton.SetUp()
				self.stoneButton.SetUp()
				self.boxButton.SetUp()
				self.titleName.SetText(localeInfo.INVENTORY_UPGRADE_ITEM_TOOLTIP)
			self.RefreshBagSlotWindow()
			
		def SetInventoryPage(self, page):
			self.inventoryPageIndex = page
			for i in range(0,len(self.inventoryTab)):
				self.inventoryTab[i].SetUp()
			self.inventoryTab[page].Down()
			self.RefreshBagSlotWindow()

		def OnPickItem(self, count):
			itemSlotIndex = self.dlgPickItem.itemGlobalSlotIndex
			selectedItemVNum = player.GetItemIndex(itemSlotIndex)
			mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_SKILL_BOOK_INVENTORY, itemSlotIndex, selectedItemVNum, count)
				
		def __InventoryLocalSlotPosToGlobalSlotPos(self, local):
			if self.inventoryType == 0:
				return self.inventoryPageIndex*player.SKILL_BOOK_INVENTORY_SLOT_COUNT + local + item.SKILL_BOOK_INVENTORY_SLOT_START
			elif self.inventoryType == 2:
				return self.inventoryPageIndex*player.STONE_INVENTORY_SLOT_COUNT + local + item.STONE_INVENTORY_SLOT_START
			elif self.inventoryType == 3:
				return self.inventoryPageIndex*player.BOX_INVENTORY_SLOT_COUNT + local + item.BOX_INVENTORY_SLOT_START
			elif self.inventoryType == 4:
				return self.inventoryPageIndex*player.EFSUN_INVENTORY_SLOT_COUNT + local + item.EFSUN_INVENTORY_SLOT_START
			elif self.inventoryType == 5:
				return self.inventoryPageIndex*player.CICEK_INVENTORY_SLOT_COUNT + local + item.CICEK_INVENTORY_SLOT_START
			else:
				return self.inventoryPageIndex*player.UPGRADE_ITEMS_INVENTORY_SLOT_COUNT + local + item.UPGRADE_ITEMS_INVENTORY_SLOT_START
				
		def GetInventoryPageIndex(self):
			return self.inventoryPageIndex
			
		def RefreshBagSlotWindow(self):
			getItemVNum=player.GetItemIndex
			getItemCount=player.GetItemCount
			setItemVNum=self.wndItem.SetItemSlot
			
			if self.inventoryType == 0:
				for i in xrange(player.SKILL_BOOK_INVENTORY_SLOT_COUNT):
					slotNumber = item.SKILL_BOOK_INVENTORY_SLOT_START + i
					if self.GetInventoryPageIndex() == 1:
						slotNumber += 45
					elif self.GetInventoryPageIndex() == 2:
						slotNumber += 90
					itemCount = getItemCount(slotNumber)
					if 0 == itemCount:
						self.wndItem.ClearSlot(i)
						continue
					elif 1 == itemCount:
						itemCount = 0	
					itemVnum = getItemVNum(slotNumber)
					setItemVNum(i, itemVnum, itemCount)
			elif self.inventoryType == 2:
				for i in xrange(player.STONE_INVENTORY_SLOT_COUNT):
					slotNumber = item.STONE_INVENTORY_SLOT_START + i
					if self.GetInventoryPageIndex() == 1:
						slotNumber += 45
					elif self.GetInventoryPageIndex() == 2:
						slotNumber += 90
					itemCount = getItemCount(slotNumber)
					if 0 == itemCount:
						self.wndItem.ClearSlot(i)
						continue
					elif 1 == itemCount:
						itemCount = 0	
					itemVnum = getItemVNum(slotNumber)
					setItemVNum(i, itemVnum, itemCount)	
			elif self.inventoryType == 3:
				for i in xrange(player.BOX_INVENTORY_SLOT_COUNT):
					slotNumber = item.BOX_INVENTORY_SLOT_START + i
					if self.GetInventoryPageIndex() == 1:
						slotNumber += 45
					elif self.GetInventoryPageIndex() == 2:
						slotNumber += 90
					itemCount = getItemCount(slotNumber)
					if 0 == itemCount:
						self.wndItem.ClearSlot(i)
						continue
					elif 1 == itemCount:
						itemCount = 0
					itemVnum = getItemVNum(slotNumber)
					setItemVNum(i, itemVnum, itemCount)	
			elif self.inventoryType == 4:
				for i in xrange(player.EFSUN_INVENTORY_SLOT_COUNT):
					slotNumber = item.EFSUN_INVENTORY_SLOT_START + i
					if self.GetInventoryPageIndex() == 1:
						slotNumber += 45
					elif self.GetInventoryPageIndex() == 2:
						slotNumber += 90
					itemCount = getItemCount(slotNumber)
					if 0 == itemCount:
						self.wndItem.ClearSlot(i)
						continue
					elif 1 == itemCount:
						itemCount = 0
					itemVnum = getItemVNum(slotNumber)
					setItemVNum(i, itemVnum, itemCount)	
			elif self.inventoryType == 5:
				for i in xrange(player.CICEK_INVENTORY_SLOT_COUNT):
					slotNumber = item.CICEK_INVENTORY_SLOT_START + i
					if self.GetInventoryPageIndex() == 1:
						slotNumber += 45
					elif self.GetInventoryPageIndex() == 2:
						slotNumber += 90
					itemCount = getItemCount(slotNumber)
					if 0 == itemCount:
						self.wndItem.ClearSlot(i)
						continue
					elif 1 == itemCount:
						itemCount = 0
					itemVnum = getItemVNum(slotNumber)
					setItemVNum(i, itemVnum, itemCount)	
			else:
				for i in xrange(player.UPGRADE_ITEMS_INVENTORY_SLOT_COUNT):
					slotNumber = item.UPGRADE_ITEMS_INVENTORY_SLOT_START + i
					if self.GetInventoryPageIndex() == 1:
						slotNumber += 45
					elif self.GetInventoryPageIndex() == 2:
						slotNumber += 90
					itemCount = getItemCount(slotNumber)
					if 0 == itemCount:
						self.wndItem.ClearSlot(i)
						continue
					elif 1 == itemCount:
						itemCount = 0
					itemVnum = getItemVNum(slotNumber)
					setItemVNum(i, itemVnum, itemCount)
			self.wndItem.RefreshSlot()

		def RefreshItemSlot(self):
			self.RefreshBagSlotWindow()

		def RefreshStatus(self):
			pass

		def SetItemToolTip(self, tooltipItem):
			self.tooltipItem = tooltipItem
			
		def SelectEmptySlot(self, selectedSlotPos):
			if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS() == 1:
				return
			
			if self.inventoryType == 0:
				selectedSlotPos += item.SKILL_BOOK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					selectedSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					selectedSlotPos += 90
			elif self.inventoryType == 2:
				selectedSlotPos += item.STONE_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					selectedSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					selectedSlotPos += 90
			elif self.inventoryType == 3:
				selectedSlotPos += item.BOX_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					selectedSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					selectedSlotPos += 90
			elif self.inventoryType == 4:
				selectedSlotPos += item.EFSUN_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					selectedSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					selectedSlotPos += 90
			elif self.inventoryType == 5:
				selectedSlotPos += item.CICEK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					selectedSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					selectedSlotPos += 90
			else:
				selectedSlotPos += item.UPGRADE_ITEMS_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					selectedSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					selectedSlotPos += 90
			
			if mouseModule.mouseController.isAttached():

				attachedSlotType = mouseModule.mouseController.GetAttachedType()
				attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
				attachedItemCount = mouseModule.mouseController.GetAttachedItemCount()
				attachedItemIndex = mouseModule.mouseController.GetAttachedItemIndex()

				if player.SLOT_TYPE_SKILL_BOOK_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_STONE_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_BOX_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_EFSUN_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_CICEK_INVENTORY == attachedSlotType:
					itemCount = player.GetItemCount(attachedSlotPos)
					attachedCount = mouseModule.mouseController.GetAttachedItemCount()
					self.__SendMoveItemPacket(attachedSlotPos, selectedSlotPos, attachedCount)

					if item.IsRefineScroll(attachedItemIndex):
						self.wndItem.SetUseMode(False)

				elif player.SLOT_TYPE_PRIVATE_SHOP == attachedSlotType:
					mouseModule.mouseController.RunCallBack("INVENTORY")

				elif player.SLOT_TYPE_SHOP == attachedSlotType:
					net.SendShopBuyPacket(attachedSlotPos)

				elif player.SLOT_TYPE_SAFEBOX == attachedSlotType:

					if player.ITEM_MONEY == attachedItemIndex:
						net.SendSafeboxWithdrawMoneyPacket(mouseModule.mouseController.GetAttachedItemCount())
						snd.PlaySound("sound/ui/money.wav")

					else:
						net.SendSafeboxCheckoutPacket(attachedSlotPos, selectedSlotPos)

				elif player.SLOT_TYPE_MALL == attachedSlotType:
					net.SendMallCheckoutPacket(attachedSlotPos, selectedSlotPos)

				mouseModule.mouseController.DeattachObject()
				
		def SelectItemSlot(self, itemSlotIndex):
			if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS() == 1:
				return
				
			if self.inventoryType == 0:
				itemSlotIndex += item.SKILL_BOOK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					itemSlotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					itemSlotIndex += 90
			elif self.inventoryType == 2:
				itemSlotIndex += item.STONE_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					itemSlotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					itemSlotIndex += 90
			elif self.inventoryType == 3:
				itemSlotIndex += item.BOX_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					itemSlotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					itemSlotIndex += 90
			elif self.inventoryType == 4:
				itemSlotIndex += item.EFSUN_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					itemSlotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					itemSlotIndex += 90
			elif self.inventoryType == 5:
				itemSlotIndex += item.CICEK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					itemSlotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					itemSlotIndex += 90
			else:
				itemSlotIndex += item.UPGRADE_ITEMS_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					itemSlotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					itemSlotIndex += 90

			if mouseModule.mouseController.isAttached():
				attachedSlotType = mouseModule.mouseController.GetAttachedType()
				attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
				attachedItemVID = mouseModule.mouseController.GetAttachedItemIndex()
				attachedItemCount = mouseModule.mouseController.GetAttachedItemCount()
				
				if player.GetItemCount(itemSlotIndex) > attachedItemCount:
					return
			
				if player.SLOT_TYPE_SKILL_BOOK_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_STONE_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_BOX_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_EFSUN_INVENTORY == attachedSlotType or\
					player.SLOT_TYPE_CICEK_INVENTORY == attachedSlotType:
					self.__SendMoveItemPacket(attachedSlotPos, itemSlotIndex, attachedItemCount)
		
				mouseModule.mouseController.DeattachObject()
			else:

				curCursorNum = app.GetCursor()
				#if app.SELL == curCursorNum:
					#self.__SellItem(itemSlotIndex)
					
				if app.BUY == curCursorNum:
					chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.SHOP_BUY_INFO)

				elif app.IsPressed(app.DIK_LALT):
					link = player.GetItemLink(itemSlotIndex)
					ime.PasteString(link)

				elif app.IsPressed(app.DIK_LALT):
					link = player.GetItemLink(itemSlotIndex)
					ime.PasteString(link)

				elif app.IsPressed(app.DIK_LSHIFT):
					itemCount = player.GetItemCount(itemSlotIndex)
				
					if itemCount > 1:
						self.dlgPickItem.SetTitleName(localeInfo.PICK_ITEM_TITLE)
						self.dlgPickItem.SetAcceptEvent(ui.__mem_func__(self.OnPickItem))
						self.dlgPickItem.Open(itemCount)
						self.dlgPickItem.itemGlobalSlotIndex = itemSlotIndex

				elif app.IsPressed(app.DIK_LCONTROL):
					itemIndex = player.GetItemIndex(itemSlotIndex)

					if TRUE == item.CanAddToQuickSlotItem(itemIndex):
						player.RequestAddToEmptyLocalQuickSlot(player.SLOT_TYPE_INVENTORY, itemSlotIndex)
					else:
						chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.QUICKSLOT_REGISTER_DISABLE_ITEM)
				else:
					selectedItemVNum = player.GetItemIndex(itemSlotIndex)
					itemCount = player.GetItemCount(itemSlotIndex)
					if self.inventoryType == 0:
						mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_SKILL_BOOK_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
					elif self.inventoryType == 2:
						mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_STONE_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
					elif self.inventoryType == 3:
						mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_BOX_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
					elif self.inventoryType == 4:
						mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_EFSUN_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
					elif self.inventoryType == 5:
						mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_CICEK_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
					else:
						mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
					self.wndItem.SetUseMode(True)

					snd.PlaySound("sound/ui/pick.wav")

		def OnCloseQuestionDialog(self):
			if not self.questionDialog:
				return
			
			self.questionDialog.Close()
			self.questionDialog = None
			constInfo.SET_ITEM_QUESTION_DIALOG_STATUS(0)

		def Sat(self):
			if self.sellingSlotitemIndex == player.GetItemIndex(self.sellingSlotNumber):
				if self.sellingSlotitemCount == player.GetItemCount(self.sellingSlotNumber):
					net.SendShopSellPacketNew(self.sellingSlotNumber, self.questionDialog.count, player.INVENTORY)
					snd.PlaySound("sound/ui/money.wav")
			self.OnCloseQuestionDialog()
			
		def __OnClosePopupDialog(self):
			self.pop = None
			
		def OverOutItem(self):
			self.wndItem.SetUsableItem(False)
			if None != self.tooltipItem:
				self.tooltipItem.HideToolTip()

		def OverInItem(self, overSlotPos):
			if self.inventoryType == 0:
				overSlotPos += item.SKILL_BOOK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					overSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					overSlotPos += 90
			elif self.inventoryType == 2:
				overSlotPos += item.STONE_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					overSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					overSlotPos += 90
			elif self.inventoryType == 3:
				overSlotPos += item.BOX_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					overSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					overSlotPos += 90
			elif self.inventoryType == 4:
				overSlotPos += item.EFSUN_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					overSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					overSlotPos += 90
			elif self.inventoryType == 5:
				overSlotPos += item.CICEK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					overSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					overSlotPos += 90
			else:
				overSlotPos += item.UPGRADE_ITEMS_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					overSlotPos += 45
				elif self.GetInventoryPageIndex() == 2:
					overSlotPos += 90
			self.wndItem.SetUsableItem(False)
			self.ShowToolTip(overSlotPos)
			
		def ShowToolTip(self, slotIndex):
			if None != self.tooltipItem:
				self.tooltipItem.SetInventoryItem(slotIndex)
				
		def OnPressEscapeKey(self):
			self.Close()
			return True	
			
		def UseItemSlot(self, slotIndex):
			if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS():
				return
				
			if self.inventoryType == 0:
				slotIndex += item.SKILL_BOOK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					slotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					slotIndex += 90
			elif self.inventoryType == 2:
				slotIndex += item.STONE_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					slotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					slotIndex += 90
			elif self.inventoryType == 3:
				slotIndex += item.BOX_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					slotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					slotIndex += 90
			elif self.inventoryType == 4:
				slotIndex += item.EFSUN_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					slotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					slotIndex += 90
			elif self.inventoryType == 5:
				slotIndex += item.CICEK_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					slotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					slotIndex += 90
			else:
				slotIndex += item.UPGRADE_ITEMS_INVENTORY_SLOT_START
				if self.GetInventoryPageIndex() == 1:
					slotIndex += 45
				elif self.GetInventoryPageIndex() == 2:
					slotIndex += 90
			self.__UseItem(slotIndex)
			mouseModule.mouseController.DeattachObject()
			self.OverOutItem()

		def __UseItem(self, slotIndex):
			ItemVNum = player.GetItemIndex(slotIndex)
			item.SelectItem(ItemVNum)

			if item.IsFlag(item.ITEM_FLAG_CONFIRM_WHEN_USE):
				self.questionDialog = uiCommon.QuestionDialog()
				self.questionDialog.SetText(localeInfo.INVENTORY_REALLY_USE_ITEM)
				self.questionDialog.SetAcceptEvent(ui.__mem_func__(self.__UseItemQuestionDialog_OnAccept))
				self.questionDialog.SetCancelEvent(ui.__mem_func__(self.__UseItemQuestionDialog_OnCancel))
				self.questionDialog.Open()
				self.questionDialog.slotIndex = slotIndex
			
				constInfo.SET_ITEM_QUESTION_DIALOG_STATUS(1)

			elif app.IsPressed(app.DIK_LSHIFT):
				if player.GetItemTypeBySlot(slotIndex) == item.ITEM_TYPE_GIFTBOX and\
					ItemVNum != 31374 and ItemVNum != 50255 and\
					ItemVNum != 50187 and ItemVNum != 50197 and\
					ItemVNum != 50188 and ItemVNum != 50189 and\
					ItemVNum != 50190 and ItemVNum != 50191 and\
					ItemVNum != 50192 and ItemVNum != 50193 and\
					ItemVNum != 50194 and ItemVNum != 50195:
					if app.ENABLE_SHOW_CHEST_DROP:
						if self.interface:
							if self.interface.dlgChestDrop:
								if not self.interface.dlgChestDrop.IsShow():
									self.interface.dlgChestDrop.Open(slotIndex)
									net.SendChestDropInfo(slotIndex)
			else:
				self.__SendUseItemPacket(slotIndex)
				
		def __UseItemQuestionDialog_OnCancel(self):
			self.OnCloseQuestionDialog()

		def __UseItemQuestionDialog_OnAccept(self):
			self.__SendUseItemPacket(self.questionDialog.slotIndex)
			self.OnCloseQuestionDialog()	
			
		def __SendUseItemPacket(self, slotPos):
			if uiPrivateShopBuilder.IsBuildingPrivateShop():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.USE_ITEM_FAILURE_PRIVATE_SHOP)
				return

			net.SendItemUsePacket(slotPos)

		def __SendMoveItemPacket(self, srcSlotPos, dstSlotPos, srcItemCount):
			if uiPrivateShopBuilder.IsBuildingPrivateShop():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.MOVE_ITEM_FAILURE_PRIVATE_SHOP)
				return

			net.SendItemMovePacket(srcSlotPos, dstSlotPos, srcItemCount)


# Arat 	def SelectEmptySlot(self, selectedSlotPos): ��inde
			if player.SLOT_TYPE_INVENTORY == attachedSlotType:

# De�i�
			if player.SLOT_TYPE_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_DRAGON_SOUL_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_SKILL_BOOK_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_STONE_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_BOX_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_EFSUN_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_CICEK_INVENTORY == attachedSlotType:
				itemCount = player.GetItemCount(attachedSlotPos)
				attachedCount = mouseModule.mouseController.GetAttachedItemCount()
				self.__SendMoveItemPacket(attachedSlotPos, selectedSlotPos, attachedCount)

# Ara 	def SelectItemSlot(self, itemSlotIndex): ��inde
			if player.SLOT_TYPE_INVENTORY == attachedSlotType:

#De�i�
			if player.SLOT_TYPE_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_SKILL_BOOK_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_STONE_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_BOX_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_EFSUN_INVENTORY == attachedSlotType or\
				player.SLOT_TYPE_CICEK_INVENTORY == attachedSlotType:

# Ara 	def OverInItem(self, overSlotPos): ��inde
			if player.SLOT_TYPE_INVENTORY == attachedItemType:

#De�i� 
			if player.SLOT_TYPE_INVENTORY == attachedItemType or player.SLOT_TYPE_STONE_INVENTORY == attachedItemType or player.SLOT_TYPE_EFSUN_INVENTORY == attachedItemType:

# Ara
		if srcSlotPos == dstSlotPos:
			return False

#De�i�
		if srcSlotPos == dstSlotPos and not item.IsMetin(srcItemVNum):
			return False

#Arat
				elif self.__CanUseSrcItemToDstItem(attachedItemVNum, attachedSlotPos, overSlotPos):
					self.wndItem.SetUsableItem(True)

# Alt�na Ekle
					self.wndItem.SetUseMode(True)





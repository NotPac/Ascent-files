# Arat
			if Type == player.SLOT_TYPE_INVENTORY or\
				Type == player.SLOT_TYPE_PRIVATE_SHOP or\
				Type == player.SLOT_TYPE_SHOP or\
				Type == player.SLOT_TYPE_SAFEBOX or\
				Type == player.SLOT_TYPE_MALL or\
				Type == player.SLOT_TYPE_DRAGON_SOUL_INVENTORY:

#De�i�
			if Type == player.SLOT_TYPE_INVENTORY or\
				Type == player.SLOT_TYPE_PRIVATE_SHOP or\
				Type == player.SLOT_TYPE_SHOP or\
				Type == player.SLOT_TYPE_SAFEBOX or\
				Type == player.SLOT_TYPE_MALL or\
				Type == player.SLOT_TYPE_DRAGON_SOUL_INVENTORY or\
				Type == player.SLOT_TYPE_SKILL_BOOK_INVENTORY or\
				Type == player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY or\
				Type == player.SLOT_TYPE_STONE_INVENTORY or\
				Type == player.SLOT_TYPE_BOX_INVENTORY or\
				Type == player.SLOT_TYPE_EFSUN_INVENTORY or\
				Type == player.SLOT_TYPE_CICEK_INVENTORY:

#Arat
			if self.AttachedType == player.SLOT_TYPE_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_PRIVATE_SHOP or\
				self.AttachedType == player.SLOT_TYPE_SHOP or\
				self.AttachedType == player.SLOT_TYPE_SAFEBOX or\
				self.AttachedType == player.SLOT_TYPE_MALL:

#De�i�
			if self.AttachedType == player.SLOT_TYPE_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_PRIVATE_SHOP or\
				self.AttachedType == player.SLOT_TYPE_SHOP or\
				self.AttachedType == player.SLOT_TYPE_SAFEBOX or\
				self.AttachedType == player.SLOT_TYPE_MALL or\
				self.AttachedType == player.SLOT_TYPE_SKILL_BOOK_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_UPGRADE_ITEMS_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_STONE_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_BOX_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_EFSUN_INVENTORY or\
				self.AttachedType == player.SLOT_TYPE_CICEK_INVENTORY:
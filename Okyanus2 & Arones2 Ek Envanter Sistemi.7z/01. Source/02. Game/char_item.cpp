// Arat
LPITEM CHARACTER::GetInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
LPITEM CHARACTER::GetSkillBookInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}
LPITEM CHARACTER::GetUpgradeItemsInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}
LPITEM CHARACTER::GetStoneInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}
LPITEM CHARACTER::GetBoxInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}
LPITEM CHARACTER::GetEfsunInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}
LPITEM CHARACTER::GetCicekInventoryItem(WORD wCell) const
{
	return GetItem(TItemPos(INVENTORY, wCell));
}
#endif

// Arat
			if ((wCell < INVENTORY_MAX_NUM) || (BELT_INVENTORY_SLOT_START <= wCell && BELT_INVENTORY_SLOT_END > wCell))
				pItem->SetWindow(INVENTORY);

// De�i�tir - https://prnt.sc/qaqhow
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
			if ((wCell < INVENTORY_MAX_NUM) || (BELT_INVENTORY_SLOT_START <= wCell && BELT_INVENTORY_SLOT_END > wCell) || (SKILL_BOOK_INVENTORY_SLOT_START <= wCell && SKILL_BOOK_INVENTORY_SLOT_END > wCell) || (UPGRADE_ITEMS_INVENTORY_SLOT_START <= wCell && UPGRADE_ITEMS_INVENTORY_SLOT_END > wCell) || (STONE_INVENTORY_SLOT_START <= wCell && STONE_INVENTORY_SLOT_END > wCell) || (BOX_INVENTORY_SLOT_START <= wCell && BOX_INVENTORY_SLOT_END > wCell) || (EFSUN_INVENTORY_SLOT_START <= wCell && EFSUN_INVENTORY_SLOT_END > wCell) || (CICEK_INVENTORY_SLOT_START <= wCell && CICEK_INVENTORY_SLOT_END > wCell))
				pItem->SetWindow(INVENTORY);
#else
			if ((wCell < INVENTORY_MAX_NUM) || (BELT_INVENTORY_SLOT_START <= wCell && BELT_INVENTORY_SLOT_END > wCell))
				pItem->SetWindow(INVENTORY);
#endif

// Arat
void CHARACTER::ClearItem()
{
	int		i;
	LPITEM	item;

	for (i = 0; i < INVENTORY_AND_EQUIP_SLOT_MAX; ++i)
	{
		if ((item = GetInventoryItem(i)))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);

			SyncQuickslot(QUICKSLOT_TYPE_ITEM, i, 255);
		}
	}
	for (i = 0; i < DRAGON_SOUL_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(DRAGON_SOUL_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (i = 0; i < SKILL_BOOK_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(SKILL_BOOK_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
	
	for (i = 0; i < UPGRADE_ITEMS_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(UPGRADE_ITEMS_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
	
	for (i = 0; i < STONE_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(STONE_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
	
	for (i = 0; i < BOX_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(BOX_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
	
	for (i = 0; i < EFSUN_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(EFSUN_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
	
	for (i = 0; i < CICEK_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(CICEK_INVENTORY, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
#endif

// Arat
			if (Cell.IsBeltInventoryPosition())
			{
				LPITEM beltItem = GetWear(WEAR_BELT);

				if (NULL == beltItem)
					return false;

				if (false == CBeltInventoryHelper::IsAvailableCell(bCell - BELT_INVENTORY_SLOT_START, beltItem->GetValue(0)))
					return false;

				if (m_pointsInstant.bItemGrid[bCell])
				{
					if (m_pointsInstant.bItemGrid[bCell] == iExceptionCell)
						return true;

					return false;
				}

				if (bSize == 1)
					return true;

			}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
			else if (Cell.IsSkillBookInventoryPosition())
			{
				if (bCell < SKILL_BOOK_INVENTORY_SLOT_START)
					return false;
				
				if (bCell > SKILL_BOOK_INVENTORY_SLOT_END)
					return false;
				
				if (m_pointsInstant.bItemGrid[bCell] == (UINT)iExceptionCell)
				{
					if (bSize == 1)
						return true;

					int j = 1;
					UINT bPage = bCell / (SKILL_BOOK_INVENTORY_MAX_NUM / 3);

					do
					{
						UINT p = bCell + (5 * j);

						if (p >= SKILL_BOOK_INVENTORY_MAX_NUM)
							return false;

						if (p / (SKILL_BOOK_INVENTORY_MAX_NUM / 3) != bPage)
							return false;

						if (m_pointsInstant.bItemGrid[p])
							if (m_pointsInstant.bItemGrid[p] != iExceptionCell)
								return false;
					}
					while (++j < bSize);

					return true;
				}
			}
			else if (Cell.IsUpgradeItemsInventoryPosition())
			{
				if (bCell < UPGRADE_ITEMS_INVENTORY_SLOT_START)
					return false;
				
				if (bCell > UPGRADE_ITEMS_INVENTORY_SLOT_END)
					return false;
				
				if (m_pointsInstant.bItemGrid[bCell] == (UINT)iExceptionCell)
				{
					if (bSize == 1)
						return true;

					int j = 1;
					UINT bPage = bCell / (UPGRADE_ITEMS_INVENTORY_MAX_NUM / 3);

					do
					{
						UINT p = bCell + (5 * j);

						if (p >= UPGRADE_ITEMS_INVENTORY_MAX_NUM)
							return false;

						if (p / (UPGRADE_ITEMS_INVENTORY_MAX_NUM / 3) != bPage)
							return false;

						if (m_pointsInstant.bItemGrid[p])
							if (m_pointsInstant.bItemGrid[p] != iExceptionCell)
								return false;
					}
					while (++j < bSize);

					return true;
				}
			}
			else if (Cell.IsStoneInventoryPosition())
			{
				if (bCell < STONE_INVENTORY_SLOT_START)
					return false;
				
				if (bCell > STONE_INVENTORY_SLOT_END)
					return false;
				
				if (m_pointsInstant.bItemGrid[bCell] == (UINT)iExceptionCell)
				{
					if (bSize == 1)
						return true;

					int j = 1;
					UINT bPage = bCell / (STONE_INVENTORY_MAX_NUM / 3);

					do
					{
						UINT p = bCell + (5 * j);

						if (p >= STONE_INVENTORY_MAX_NUM)
							return false;

						if (p / (STONE_INVENTORY_MAX_NUM / 3) != bPage)
							return false;

						if (m_pointsInstant.bItemGrid[p])
							if (m_pointsInstant.bItemGrid[p] != iExceptionCell)
								return false;
					}
					while (++j < bSize);

					return true;
				}
			}
			else if (Cell.IsBoxInventoryPosition())
			{
				if (bCell < BOX_INVENTORY_SLOT_START)
					return false;
				
				if (bCell > BOX_INVENTORY_SLOT_END)
					return false;
				
				if (m_pointsInstant.bItemGrid[bCell] == (UINT)iExceptionCell)
				{
					if (bSize == 1)
						return true;

					int j = 1;
					UINT bPage = bCell / (BOX_INVENTORY_MAX_NUM / 3);

					do
					{
						UINT p = bCell + (5 * j);

						if (p >= BOX_INVENTORY_MAX_NUM)
							return false;

						if (p / (BOX_INVENTORY_MAX_NUM / 3) != bPage)
							return false;

						if (m_pointsInstant.bItemGrid[p])
							if (m_pointsInstant.bItemGrid[p] != iExceptionCell)
								return false;
					}
					while (++j < bSize);

					return true;
				}
			}
			else if (Cell.IsEfsunInventoryPosition())
			{
				if (bCell < EFSUN_INVENTORY_SLOT_START)
					return false;
				
				if (bCell > EFSUN_INVENTORY_SLOT_END)
					return false;
				
				if (m_pointsInstant.bItemGrid[bCell] == (UINT)iExceptionCell)
				{
					if (bSize == 1)
						return true;

					int j = 1;
					UINT bPage = bCell / (EFSUN_INVENTORY_MAX_NUM / 3);

					do
					{
						UINT p = bCell + (5 * j);

						if (p >= EFSUN_INVENTORY_MAX_NUM)
							return false;

						if (p / (EFSUN_INVENTORY_MAX_NUM / 3) != bPage)
							return false;

						if (m_pointsInstant.bItemGrid[p])
							if (m_pointsInstant.bItemGrid[p] != iExceptionCell)
								return false;
					}
					while (++j < bSize);

					return true;
				}
			}
			else if (Cell.IsCicekInventoryPosition())
			{
				if (bCell < CICEK_INVENTORY_SLOT_START)
					return false;
				
				if (bCell > CICEK_INVENTORY_SLOT_END)
					return false;
				
				if (m_pointsInstant.bItemGrid[bCell] == (UINT)iExceptionCell)
				{
					if (bSize == 1)
						return true;

					int j = 1;
					UINT bPage = bCell / (CICEK_INVENTORY_MAX_NUM / 3);

					do
					{
						UINT p = bCell + (5 * j);

						if (p >= CICEK_INVENTORY_MAX_NUM)
							return false;

						if (p / (CICEK_INVENTORY_MAX_NUM / 3) != bPage)
							return false;

						if (m_pointsInstant.bItemGrid[p])
							if (m_pointsInstant.bItemGrid[p] != iExceptionCell)
								return false;
					}
					while (++j < bSize);

					return true;
				}
			}
#endif

// Arat
int CHARACTER::GetEmptyDragonSoulInventory(LPITEM pItem) const
{
	if (NULL == pItem || !pItem->IsDragonSoul())
		return -1;
	if (!DragonSoul_IsQualified())
	{
		return -1;
	}
	BYTE bSize = pItem->GetSize();
	WORD wBaseCell = DSManager::instance().GetBasePosition(pItem);

	if (WORD_MAX == wBaseCell)
		return -1;

	for (int i = 0; i < DRAGON_SOUL_BOX_SIZE; ++i)
		if (IsEmptyItemGrid(TItemPos(DRAGON_SOUL_INVENTORY, i + wBaseCell), bSize))
			return i + wBaseCell;

	return -1;
}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
int CHARACTER::GetEmptySkillBookInventory(BYTE size) const
{
	for (int i = SKILL_BOOK_INVENTORY_SLOT_START; i < SKILL_BOOK_INVENTORY_SLOT_END; ++i)
		if (IsEmptyItemGrid(TItemPos(INVENTORY, i), size))
			return i;
		
	return -1;
}

int CHARACTER::GetEmptyUpgradeItemsInventory(BYTE size) const
{
	for (int i = UPGRADE_ITEMS_INVENTORY_SLOT_START; i < UPGRADE_ITEMS_INVENTORY_SLOT_END; ++i)
		if (IsEmptyItemGrid(TItemPos(INVENTORY, i), size))
			return i;
		
	return -1;
}

int CHARACTER::GetEmptyStoneInventory(BYTE size) const
{
	for (int i = STONE_INVENTORY_SLOT_START; i < STONE_INVENTORY_SLOT_END; ++i)
		if (IsEmptyItemGrid(TItemPos(INVENTORY, i), size))
			return i;
		
	return -1;
}

int CHARACTER::GetEmptyBoxInventory(BYTE size) const
{
	for (int i = BOX_INVENTORY_SLOT_START; i < BOX_INVENTORY_SLOT_END; ++i)
		if (IsEmptyItemGrid(TItemPos(INVENTORY, i), size))
			return i;
		
	return -1;
}

int CHARACTER::GetEmptyEfsunInventory(BYTE size) const
{
	for (int i = EFSUN_INVENTORY_SLOT_START; i < EFSUN_INVENTORY_SLOT_END; ++i)
		if (IsEmptyItemGrid(TItemPos(INVENTORY, i), size))
			return i;
		
	return -1;
}

int CHARACTER::GetEmptyCicekInventory(BYTE size) const
{
	for (int i = CICEK_INVENTORY_SLOT_START; i < CICEK_INVENTORY_SLOT_END; ++i)
		if (IsEmptyItemGrid(TItemPos(INVENTORY, i), size))
			return i;
		
	return -1;
}
#endif

// Arat int CHARACTER::CountEmptyInventory() const i�inde
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir - https://prnt.sc/qaqihk
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (int i = 0; i < INVENTORY_AND_EQUIP_SLOT_MAX; ++i)
#else
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat bool CHARACTER::MoveItem(TItemPos Cell, TItemPos DestCell, BYTE count) ��inde
	if (INVENTORY == Cell.window_type && Cell.cell >= INVENTORY_MAX_NUM && IS_SET(item->GetFlag(), ITEM_FLAG_IRREMOVABLE))
		return false;

// De�i�tir - https://prnt.sc/qaqirn
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	if (INVENTORY == Cell.window_type && Cell.cell >= INVENTORY_AND_EQUIP_SLOT_MAX && IS_SET(item->GetFlag(), ITEM_FLAG_IRREMOVABLE))
		return false;
#else
	if (INVENTORY == Cell.window_type && Cell.cell >= INVENTORY_MAX_NUM && IS_SET(item->GetFlag(), ITEM_FLAG_IRREMOVABLE))
		return false;
#endif

// Arat
	// ��ȹ���� ��û���� ��Ʈ �κ��丮���� Ư�� Ÿ���� �����۸� ���� �� �ִ�.
	if (DestCell.IsBeltInventoryPosition() && false == CBeltInventoryHelper::CanMoveIntoBeltInventory(item))
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�� �������� ��Ʈ �κ��丮�� �ű� �� �����ϴ�."));
		return false;
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	if (Cell.IsSkillBookInventoryPosition() && !DestCell.IsSkillBookInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsUpgradeItemsInventoryPosition() && !DestCell.IsUpgradeItemsInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsStoneInventoryPosition() && !DestCell.IsStoneInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsBoxInventoryPosition() && !DestCell.IsBoxInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEfsunInventoryPosition() && !DestCell.IsEfsunInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsCicekInventoryPosition() && !DestCell.IsCicekInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsDefaultInventoryPosition() && DestCell.IsSkillBookInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsDefaultInventoryPosition() && DestCell.IsUpgradeItemsInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsDefaultInventoryPosition() && DestCell.IsStoneInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsDefaultInventoryPosition() && DestCell.IsBoxInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsDefaultInventoryPosition() && DestCell.IsEfsunInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsDefaultInventoryPosition() && DestCell.IsCicekInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEquipPosition() && DestCell.IsSkillBookInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEquipPosition() && DestCell.IsUpgradeItemsInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEquipPosition() && DestCell.IsStoneInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEquipPosition() && DestCell.IsBoxInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEquipPosition() && DestCell.IsEfsunInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
	if (Cell.IsEquipPosition() && DestCell.IsCicekInventoryPosition())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("Cannot move item this window."));
		return false;
	}
#endif

// Arat bool CHARACTER::PickupItem(DWORD dwVID) i�inde
					for (int i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir - https://prnt.sc/qaqj2l
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
					for (int i = 0; i < INVENTORY_AND_EQUIP_SLOT_MAX; ++i)
#else
					for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat bool CHARACTER::PickupItem(DWORD dwVID) ��inde
				int iEmptyCell;
				if (item->IsDragonSoul())
				{
					if ((iEmptyCell = GetEmptyDragonSoulInventory(item)) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
				else if (item->IsSkillBook())
				{
					if ((iEmptyCell = GetEmptySkillBookInventory(item->GetSize())) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
				else if (item->IsUpgradeItem())
				{
					if ((iEmptyCell = GetEmptyUpgradeItemsInventory(item->GetSize())) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
				else if (item->IsStone())
				{
					if ((iEmptyCell = GetEmptyStoneInventory(item->GetSize())) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
				else if (item->IsBox())
				{
					if ((iEmptyCell = GetEmptyBoxInventory(item->GetSize())) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
				else if (item->IsEfsun())
				{
					if ((iEmptyCell = GetEmptyEfsunInventory(item->GetSize())) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
				else if (item->IsCicek())
				{
					if ((iEmptyCell = GetEmptyCicekInventory(item->GetSize())) == -1)
					{
						sys_log(0, "No empty ds inventory pid %u size %ud itemid %u", GetPlayerID(), item->GetSize(), item->GetID());
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
#endif

// Arat bool CHARACTER::PickupItem(DWORD dwVID) ��inde
				item->RemoveFromGround();

				if (item->IsDragonSoul())
					item->AddToCharacter(this, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyCell));

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
				else if (item->IsSkillBook())
					item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
				else if (item->IsUpgradeItem())
					item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
				else if (item->IsStone())
					item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
				else if (item->IsBox())
					item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
				else if (item->IsEfsun())
					item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
				else if (item->IsCicek())
					item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
#endif


// Arat bool CHARACTER::PickupItem(DWORD dwVID) ��inde
			int iEmptyCell;

			if (item->IsDragonSoul())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptyDragonSoulInventory(item)) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptyDragonSoulInventory(item)) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
			else if (item->IsSkillBook())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptySkillBookInventory(item->GetSize())) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptySkillBookInventory(item->GetSize())) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}
			else if (item->IsUpgradeItem())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptyUpgradeItemsInventory(item->GetSize())) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptyUpgradeItemsInventory(item->GetSize())) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}
			else if (item->IsStone())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptyStoneInventory(item->GetSize())) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptyStoneInventory(item->GetSize())) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}
			else if (item->IsBox())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptyBoxInventory(item->GetSize())) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptyBoxInventory(item->GetSize())) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}
			else if (item->IsEfsun())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptyEfsunInventory(item->GetSize())) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptyEfsunInventory(item->GetSize())) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}
			else if (item->IsCicek())
			{
				if (!(owner && (iEmptyCell = owner->GetEmptyCicekInventory(item->GetSize())) != -1))
				{
					owner = this;

					if ((iEmptyCell = GetEmptyCicekInventory(item->GetSize())) == -1)
					{
						owner->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�����ϰ� �ִ� �������� �ʹ� �����ϴ�."));
						return false;
					}
				}
			}
#endif


// Arat bool CHARACTER::PickupItem(DWORD dwVID) ��inde
			item->RemoveFromGround();

			if (item->IsDragonSoul())
				item->AddToCharacter(owner, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyCell));

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
			else if (item->IsSkillBook())
				item->AddToCharacter(owner, TItemPos(INVENTORY, iEmptyCell));
			else if (item->IsUpgradeItem())
				item->AddToCharacter(owner, TItemPos(INVENTORY, iEmptyCell));
			else if (item->IsStone())
				item->AddToCharacter(owner, TItemPos(INVENTORY, iEmptyCell));
			else if (item->IsBox())
				item->AddToCharacter(owner, TItemPos(INVENTORY, iEmptyCell));
			else if (item->IsEfsun())
				item->AddToCharacter(owner, TItemPos(INVENTORY, iEmptyCell));
			else if (item->IsCicek())
				item->AddToCharacter(owner, TItemPos(INVENTORY, iEmptyCell));
#endif

// Arat
bool CHARACTER::UnequipItem(LPITEM item)
{
	if (false == CanUnequipNow(item))
		return false;

	int pos;
	if (item->IsDragonSoul())
		pos = GetEmptyDragonSoulInventory(item);

// Ekle - https://prnt.sc/qaqk44
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	else if (item->IsSkillBook())
		pos = GetEmptySkillBookInventory(item->GetSize());
	else if (item->IsUpgradeItem())
		pos = GetEmptyUpgradeItemsInventory(item->GetSize());
	else if (item->IsStone())
		pos = GetEmptyStoneInventory(item->GetSize());
	else if (item->IsBox())
		pos = GetEmptyBoxInventory(item->GetSize());
	else if (item->IsEfsun())
		pos = GetEmptyEfsunInventory(item->GetSize());
	else if (item->IsCicek())
		pos = GetEmptyCicekInventory(item->GetSize());
#endif

// Arat
	// HARD CODING
	if (item->GetVnum() == UNIQUE_ITEM_HIDE_ALIGNMENT_TITLE)
		ShowAlignment(true);

	if (item->IsDragonSoul())
		item->AddToCharacter(this, TItemPos(DRAGON_SOUL_INVENTORY, pos));

// Ekle - https://prnt.sc/qaqk97
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	else if (item->IsSkillBook())
		item->AddToCharacter(this, TItemPos(SKILL_BOOK_INVENTORY, pos));
	else if (item->IsUpgradeItem())
		item->AddToCharacter(this, TItemPos(UPGRADE_ITEMS_INVENTORY, pos));
	else if (item->IsStone())
		item->AddToCharacter(this, TItemPos(STONE_INVENTORY, pos));
	else if (item->IsBox())
		item->AddToCharacter(this, TItemPos(BOX_INVENTORY, pos));
	else if (item->IsEfsun())
		item->AddToCharacter(this, TItemPos(EFSUN_INVENTORY, pos));
	else if (item->IsCicek())
		item->AddToCharacter(this, TItemPos(CICEK_INVENTORY, pos));
#endif

// Arat LPITEM CHARACTER::FindSpecifyItem(DWORD vnum) const ��inde
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (int i = 0; i < INVENTORY_AND_EQUIP_SLOT_MAX; ++i)
#else
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat LPITEM CHARACTER::FindItemByID(DWORD id) const ��inde
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (int i = 0; i < INVENTORY_AND_EQUIP_SLOT_MAX; ++i)
#else
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat
int CHARACTER::CountSpecifyItem(DWORD vnum) const
{
	int	count = 0;
	LPITEM item;

	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
	{
		item = GetInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			// ���� ������ ��ϵ� �����̸� �Ѿ��.
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (int i = SKILL_BOOK_INVENTORY_SLOT_START; i < SKILL_BOOK_INVENTORY_SLOT_END; ++i)
	{
		item = GetSkillBookInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}
	
	for (int i = UPGRADE_ITEMS_INVENTORY_SLOT_START; i < UPGRADE_ITEMS_INVENTORY_SLOT_END; ++i)
	{
		item = GetUpgradeItemsInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}
	
	for (int i = STONE_INVENTORY_SLOT_START; i < STONE_INVENTORY_SLOT_END; ++i)
	{
		item = GetStoneInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}
	
	for (int i = BOX_INVENTORY_SLOT_START; i < BOX_INVENTORY_SLOT_END; ++i)
	{
		item = GetBoxInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}
	
	for (int i = EFSUN_INVENTORY_SLOT_START; i < EFSUN_INVENTORY_SLOT_END; ++i)
	{
		item = GetEfsunInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}
	
	for (int i = CICEK_INVENTORY_SLOT_START; i < CICEK_INVENTORY_SLOT_END; ++i)
	{
		item = GetCicekInventoryItem(i);
		if (NULL != item && item->GetVnum() == vnum)
		{
			if (m_pkMyShop && m_pkMyShop->IsSellingItem(item->GetID()))
			{
				continue;
			}
			else
			{
				count += item->GetCount();
			}
		}
	}
#endif

// Arat void CHARACTER::RemoveSpecifyItem(DWORD vnum, DWORD count) ��inde
			if (0 == count)
				return;
		}
		else
		{
			GetInventoryItem(i)->SetCount(GetInventoryItem(i)->GetCount() - count);
			return;
		}
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (UINT i = SKILL_BOOK_INVENTORY_SLOT_START; i < CICEK_INVENTORY_SLOT_END; ++i)
	{
		if (NULL == GetInventoryItem(i))
			continue;

		if (GetInventoryItem(i)->GetVnum() != vnum)
			continue;

		if(m_pkMyShop)
		{
			bool isItemSelling = m_pkMyShop->IsSellingItem(GetInventoryItem(i)->GetID());
			if (isItemSelling)
				continue;
		}

		if (vnum >= 80003 && vnum <= 80007)
			LogManager::instance().GoldBarLog(GetPlayerID(), GetInventoryItem(i)->GetID(), QUEST, "RemoveSpecifyItem");

		if (count >= GetInventoryItem(i)->GetCount())
		{
			count -= GetInventoryItem(i)->GetCount();
			GetInventoryItem(i)->SetCount(0);

			if (0 == count)
				return;
		}
		else
		{
			GetInventoryItem(i)->SetCount(GetInventoryItem(i)->GetCount() - count);
			return;
		}
	}
#endif

// Arat int CHARACTER::CountSpecifyTypeItem(BYTE type) const ��inde
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (int i = SKILL_BOOK_INVENTORY_SLOT_START; i < STONE_INVENTORY_SLOT_END; ++i)
#else
	for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat void CHARACTER::RemoveSpecifyTypeItem(BYTE type, DWORD count) ��inde
	for (UINT i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	for (UINT i = SKILL_BOOK_INVENTORY_SLOT_START; i < STONE_INVENTORY_SLOT_END; ++i)
#else
	for (UINT i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat void CHARACTER::AutoGiveItem(LPITEM item, bool longOwnerShip) ��inde
	int cell;
	if (item->IsDragonSoul())
	{
		cell = GetEmptyDragonSoulInventory(item);
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	else if (item->IsSkillBook())
	{
		cell = GetEmptySkillBookInventory(item->GetSize());
	}
	else if (item->IsUpgradeItem())
	{
		cell = GetEmptyUpgradeItemsInventory(item->GetSize());
	}
	else if (item->IsStone())
	{
		cell = GetEmptyStoneInventory(item->GetSize());
	}
	else if (item->IsBox())
	{
		cell = GetEmptyBoxInventory(item->GetSize());
	}
	else if (item->IsEfsun())
	{
		cell = GetEmptyEfsunInventory(item->GetSize());
	}
	else if (item->IsCicek())
	{
		cell = GetEmptyCicekInventory(item->GetSize());
	}
#endif

// Ayn� blok i�inde arat
	if (cell != -1)
	{
		if (item->IsDragonSoul())
			item->AddToCharacter(this, TItemPos(DRAGON_SOUL_INVENTORY, cell));

// Ekle - https://prnt.sc/qaqll8
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
			item->AddToCharacter(this, TItemPos(INVENTORY, cell));
		else if (item->IsUpgradeItem())
			item->AddToCharacter(this, TItemPos(INVENTORY, cell));
		else if (item->IsStone())
			item->AddToCharacter(this, TItemPos(INVENTORY, cell));
		else if (item->IsBox())
			item->AddToCharacter(this, TItemPos(INVENTORY, cell));
		else if (item->IsEfsun())
			item->AddToCharacter(this, TItemPos(INVENTORY, cell));
		else if (item->IsCicek())
			item->AddToCharacter(this, TItemPos(INVENTORY, cell));
#endif

// Arat LPITEM CHARACTER::AutoGiveItem(DWORD dwItemVnum, BYTE bCount, int iRarePct, bool bMsg) ��inde
		for (int i = 0; i < INVENTORY_MAX_NUM; ++i)

// De�i�tir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		for (int i = 0; i < INVENTORY_AND_EQUIP_SLOT_MAX; ++i)
#else
		for (int i = 0; i < INVENTORY_MAX_NUM; ++i)
#endif

// Arat LPITEM CHARACTER::AutoGiveItem(DWORD dwItemVnum, BYTE bCount, int iRarePct, bool bMsg) ��inde ( Yanl��l�k yok iki defa var)
		for (int i=0; i < INVENTORY_MAX_NUM; i++)

// De�i�tir
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		for (int i=0; i < INVENTORY_AND_EQUIP_SLOT_MAX; i++)
#else
		for (int i=0; i < INVENTORY_MAX_NUM; i++)
#endif

// Arat LPITEM CHARACTER::AutoGiveItem(DWORD dwItemVnum, BYTE bCount, int iRarePct, bool bMsg) ��inde
	int iEmptyCell;
	if (item->IsDragonSoul())
	{
		iEmptyCell = GetEmptyDragonSoulInventory(item);
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	else if (item->IsSkillBook())
	{
		iEmptyCell = GetEmptySkillBookInventory(item->GetSize());
	}
	else if (item->IsUpgradeItem())
	{
		iEmptyCell = GetEmptyUpgradeItemsInventory(item->GetSize());
	}
	else if (item->IsStone())
	{
		iEmptyCell = GetEmptyStoneInventory(item->GetSize());
	}
	else if (item->IsBox())
	{
		iEmptyCell = GetEmptyBoxInventory(item->GetSize());
	}
	else if (item->IsEfsun())
	{
		iEmptyCell = GetEmptyEfsunInventory(item->GetSize());
	}
	else if (item->IsCicek())
	{
		iEmptyCell = GetEmptyCicekInventory(item->GetSize());
	}
#endif

// Arat LPITEM CHARACTER::AutoGiveItem(DWORD dwItemVnum, BYTE bCount, int iRarePct, bool bMsg) ��inde
	if (iEmptyCell != -1)
	{
		if (bMsg)
			ChatPacket(CHAT_TYPE_INFO, LC_TEXT("������ ȹ��: %s"), item->GetName());

		if (item->IsDragonSoul())
			item->AddToCharacter(this, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyCell));

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
			item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
		else if (item->IsUpgradeItem())
			item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
		else if (item->IsStone())
			item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
		else if (item->IsBox())
			item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
		else if (item->IsEfsun())
			item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
		else if (item->IsCicek())
			item->AddToCharacter(this, TItemPos(INVENTORY, iEmptyCell));
#endif

// Arat bool CHARACTER::CanUnequipNow(const LPITEM item, const TItemPos& srcCell, const TItemPos& destCell) ��inde
		int pos = -1;

		if (item->IsDragonSoul())
			pos = GetEmptyDragonSoulInventory(item);

// Ekle - https://prnt.sc/qaqmly
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
		else if (item->IsSkillBook())
			pos = GetEmptySkillBookInventory(item->GetSize());
		else if (item->IsUpgradeItem())
			pos = GetEmptyUpgradeItemsInventory(item->GetSize());
		else if (item->IsStone())
			pos = GetEmptyStoneInventory(item->GetSize());
		else if (item->IsBox())
			pos = GetEmptyBoxInventory(item->GetSize());
		else if (item->IsEfsun())
			pos = GetEmptyEfsunInventory(item->GetSize());
		else if (item->IsCicek())
			pos = GetEmptyCicekInventory(item->GetSize());
#endif

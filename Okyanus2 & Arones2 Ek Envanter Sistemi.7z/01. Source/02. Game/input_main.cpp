// Arat
		if (!DSManager::instance().IsValidCellForThisItem(pkItem, DestPos))
		{
			int iCell = ch->GetEmptyDragonSoulInventory(pkItem);
			if (iCell < 0)
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
				return ;
			}
			DestPos = TItemPos (DRAGON_SOUL_INVENTORY, iCell);
		}

		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, DestPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}

// Ekle
#ifdef ENABLE_SPLIT_INVENTORY_SYSTEM
	else if (pkItem->IsSkillBook())
	{
		if (DRAGON_SOUL_INVENTORY == p->ItemPos.window_type)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
			return;
		}
		
		if (p->ItemPos.IsSkillBookInventoryPosition() == false)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_MOVE_ITEM_THIS_WINDOW"));
			return;
		}
		
		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, p->ItemPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}
	else if (pkItem->IsUpgradeItem())
	{
		if (DRAGON_SOUL_INVENTORY == p->ItemPos.window_type)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
			return;
		}
		
		if (p->ItemPos.IsUpgradeItemsInventoryPosition() == false)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_MOVE_ITEM_THIS_WINDOW"));
			return;
		}
		
		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, p->ItemPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}
	else if (pkItem->IsStone())
	{
		if (DRAGON_SOUL_INVENTORY == p->ItemPos.window_type)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
			return;
		}
		
		if (p->ItemPos.IsStoneInventoryPosition() == false)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_MOVE_ITEM_THIS_WINDOW"));
			return;
		}
		
		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, p->ItemPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}
	else if (pkItem->IsBox())
	{
		if (DRAGON_SOUL_INVENTORY == p->ItemPos.window_type)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
			return;
		}
		
		if (p->ItemPos.IsBoxInventoryPosition() == false)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_MOVE_ITEM_THIS_WINDOW"));
			return;
		}
		
		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, p->ItemPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}
	else if (pkItem->IsEfsun())
	{
		if (DRAGON_SOUL_INVENTORY == p->ItemPos.window_type)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
			return;
		}
		
		if (p->ItemPos.IsEfsunInventoryPosition() == false)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_MOVE_ITEM_THIS_WINDOW"));
			return;
		}
		
		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, p->ItemPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}
	else if (pkItem->IsCicek())
	{
		if (DRAGON_SOUL_INVENTORY == p->ItemPos.window_type)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("<â��> �ű� �� ���� ��ġ�Դϴ�."));
			return;
		}
		
		if (p->ItemPos.IsCicekInventoryPosition() == false)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_MOVE_ITEM_THIS_WINDOW"));
			return;
		}
		
		pkSafebox->Remove(p->bSafePos);
		pkItem->AddToCharacter(ch, p->ItemPos);
		ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
	}
#endif

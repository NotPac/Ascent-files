// Arat
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
	// ��Ʈ �������� �����ϴ� �κ��丮
	const DWORD c_Belt_Inventory_Slot_Start = c_DragonSoul_Equip_End + c_DragonSoul_Equip_Reserved_Count;
	const DWORD c_Belt_Inventory_Width = 4;
	const DWORD c_Belt_Inventory_Height= 4;
	const DWORD c_Belt_Inventory_Slot_Count = c_Belt_Inventory_Width * c_Belt_Inventory_Height;
	const DWORD c_Belt_Inventory_Slot_End = c_Belt_Inventory_Slot_Start + c_Belt_Inventory_Slot_Count;

	const DWORD c_Inventory_Count	= c_Belt_Inventory_Slot_End;
#else
	const DWORD c_Inventory_Count	= c_DragonSoul_Equip_End;
#endif

// De�i�tir
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
	// ��Ʈ �������� �����ϴ� �κ��丮
	const DWORD c_Belt_Inventory_Slot_Start = c_DragonSoul_Equip_End + c_DragonSoul_Equip_Reserved_Count;
	const DWORD c_Belt_Inventory_Width = 4;
	const DWORD c_Belt_Inventory_Height= 4;
	const DWORD c_Belt_Inventory_Slot_Count = c_Belt_Inventory_Width * c_Belt_Inventory_Height;
	const DWORD c_Belt_Inventory_Slot_End = c_Belt_Inventory_Slot_Start + c_Belt_Inventory_Slot_Count;
#endif

// De�i�tirlen blo�un alt�na Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	const DWORD c_Skill_Book_Inventory_Slot_Start = c_Belt_Inventory_Slot_End;
	const DWORD c_Skill_Book_Inventory_Slot_Count = 135;
	const DWORD c_Skill_Book_Inventory_Slot_End = c_Skill_Book_Inventory_Slot_Start + c_Skill_Book_Inventory_Slot_Count;
	
	const DWORD c_Upgrade_Items_Inventory_Slot_Start = c_Skill_Book_Inventory_Slot_End;
	const DWORD c_Upgrade_Items_Inventory_Slot_Count = 135;
	const DWORD c_Upgrade_Items_Inventory_Slot_End = c_Upgrade_Items_Inventory_Slot_Start + c_Upgrade_Items_Inventory_Slot_Count;
	
	const DWORD c_Stone_Inventory_Slot_Start = c_Upgrade_Items_Inventory_Slot_End;
	const DWORD c_Stone_Inventory_Slot_Count = 135;
	const DWORD c_Stone_Inventory_Slot_End = c_Stone_Inventory_Slot_Start + c_Stone_Inventory_Slot_Count;
	
	const DWORD c_Box_Inventory_Slot_Start = c_Stone_Inventory_Slot_End;
	const DWORD c_Box_Inventory_Slot_Count = 135;
	const DWORD c_Box_Inventory_Slot_End = c_Box_Inventory_Slot_Start + c_Box_Inventory_Slot_Count;
	
	const DWORD c_Efsun_Inventory_Slot_Start = c_Box_Inventory_Slot_End;
	const DWORD c_Efsun_Inventory_Slot_Count = 135;
	const DWORD c_Efsun_Inventory_Slot_End = c_Efsun_Inventory_Slot_Start + c_Efsun_Inventory_Slot_Count;
	
	const DWORD c_Cicek_Inventory_Slot_Start = c_Efsun_Inventory_Slot_End;
	const DWORD c_Cicek_Inventory_Slot_Count = 135;
	const DWORD c_Cicek_Inventory_Slot_End = c_Cicek_Inventory_Slot_Start + c_Cicek_Inventory_Slot_Count;
	
	const DWORD c_Inventory_Count	= c_Cicek_Inventory_Slot_End;
#endif

// Arat
enum ESlotType
{
	SLOT_TYPE_NONE,
	SLOT_TYPE_INVENTORY,
	SLOT_TYPE_SKILL,
	SLOT_TYPE_EMOTION,
	SLOT_TYPE_SHOP,
	SLOT_TYPE_EXCHANGE_OWNER,
	SLOT_TYPE_EXCHANGE_TARGET,
	SLOT_TYPE_QUICK_SLOT,
	SLOT_TYPE_SAFEBOX,
	SLOT_TYPE_PRIVATE_SHOP,
	SLOT_TYPE_MALL,
	SLOT_TYPE_DRAGON_SOUL_INVENTORY,

// Alt�na Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	SLOT_TYPE_SKILL_BOOK_INVENTORY,
	SLOT_TYPE_UPGRADE_ITEMS_INVENTORY,
	SLOT_TYPE_STONE_INVENTORY,
	SLOT_TYPE_BOX_INVENTORY,
	SLOT_TYPE_EFSUN_INVENTORY,
	SLOT_TYPE_CICEK_INVENTORY,
#endif

// Arat
enum EWindows
{
	RESERVED_WINDOW,
	INVENTORY,				// �⺻ �κ��丮. (45ĭ ¥���� 2������ ���� = 90ĭ)
	EQUIPMENT,
	SAFEBOX,
	MALL,
	DRAGON_SOUL_INVENTORY,
	GROUND,					// NOTE: 2013�� 2��5�� ������� unused.. �� �ִ°���???
	BELT_INVENTORY,

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	SKILL_BOOK_INVENTORY,
	UPGRADE_ITEMS_INVENTORY,
	STONE_INVENTORY,
	BOX_INVENTORY,
	EFSUN_INVENTORY,
	CICEK_INVENTORY,
#endif

// Arat
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
	bool IsBeltInventoryCell()
	{
		bool bResult = c_Belt_Inventory_Slot_Start <= cell && c_Belt_Inventory_Slot_End > cell;
		return bResult;
	}
#endif

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	bool IsSkillBookInventoryCell()
	{
		bool bResult = c_Skill_Book_Inventory_Slot_Start <= cell && c_Skill_Book_Inventory_Slot_End > cell;
		return bResult;
	}
	
	bool IsUpgradeItemsInventoryCell()
	{
		bool bResult = c_Upgrade_Items_Inventory_Slot_Start <= cell && c_Upgrade_Items_Inventory_Slot_End > cell;
		return bResult;
	}
	
	bool IsStoneInventoryCell()
	{
		bool bResult = c_Stone_Inventory_Slot_Start <= cell && c_Stone_Inventory_Slot_End > cell;
		return bResult;
	}
	
	bool IsBoxInventoryCell()
	{
		bool bResult = c_Box_Inventory_Slot_Start <= cell && c_Box_Inventory_Slot_End > cell;
		return bResult;
	}
	
	bool IsEfsunInventoryCell()
	{
		bool bResult = c_Efsun_Inventory_Slot_Start <= cell && c_Efsun_Inventory_Slot_End > cell;
		return bResult;
	}
	
	bool IsCicekInventoryCell()
	{
		bool bResult = c_Cicek_Inventory_Slot_Start <= cell && c_Cicek_Inventory_Slot_End > cell;
		return bResult;
	}
#endif

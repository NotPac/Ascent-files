// Arat
#ifdef ENABLE_NEW_EQUIPMENT_SYSTEM
	PyModule_AddIntConstant(poModule, "BELT_INVENTORY_SLOT_START",			c_Belt_Inventory_Slot_Start);
	PyModule_AddIntConstant(poModule, "BELT_INVENTORY_SLOT_COUNT",			c_Belt_Inventory_Slot_Count);
	PyModule_AddIntConstant(poModule, "BELT_INVENTORY_SLOT_END",			c_Belt_Inventory_Slot_End);
#endif

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	PyModule_AddIntConstant(poModule, "SKILL_BOOK_INVENTORY_SLOT_START",	c_Skill_Book_Inventory_Slot_Start);
	PyModule_AddIntConstant(poModule, "UPGRADE_ITEMS_INVENTORY_SLOT_START",	c_Upgrade_Items_Inventory_Slot_Start);
	PyModule_AddIntConstant(poModule, "STONE_INVENTORY_SLOT_START",	c_Stone_Inventory_Slot_Start);
	PyModule_AddIntConstant(poModule, "BOX_INVENTORY_SLOT_START",	c_Box_Inventory_Slot_Start);
	PyModule_AddIntConstant(poModule, "EFSUN_INVENTORY_SLOT_START",	c_Efsun_Inventory_Slot_Start);
	PyModule_AddIntConstant(poModule, "CICEK_INVENTORY_SLOT_START",	c_Cicek_Inventory_Slot_Start);
#endif
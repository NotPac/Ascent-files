// Arat
#ifdef ENABLE_ENERGY_SYSTEM
	PyModule_AddIntConstant(poModule, "ENABLE_ENERGY_SYSTEM",	1);
#else
	PyModule_AddIntConstant(poModule, "ENABLE_ENERGY_SYSTEM",	0);
#endif

// Ekle
#ifdef WJ_SPLIT_INVENTORY_SYSTEM
	PyModule_AddIntConstant(poModule, "WJ_SPLIT_INVENTORY_SYSTEM", 1);
#else
	PyModule_AddIntConstant(poModule, "WJ_SPLIT_INVENTORY_SYSTEM", 0);
#endif
